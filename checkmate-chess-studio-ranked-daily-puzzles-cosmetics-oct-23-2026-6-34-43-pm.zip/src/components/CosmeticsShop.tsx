import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { PlayerProfile, PieceType } from '../types/chess';
import { BOARD_THEMES, PIECE_SETS } from '../data/cosmetics';
import { sounds } from '../utils/soundEffects';
import { Sparkles, Coins, Check, Lock, Palette } from 'lucide-react';

interface CosmeticsShopProps {
  profile: PlayerProfile;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
}

export const CosmeticsShop: React.FC<CosmeticsShopProps> = ({
  profile,
  onUpdateProfile
}) => {
  const [activeTab, setActiveTab] = useState<'pieces' | 'boards'>('pieces');
  const [previewPieceSet, setPreviewPieceSet] = useState(profile.equippedPieceSet);
  const [previewBoardTheme, setPreviewBoardTheme] = useState(profile.equippedBoardTheme);

  const selectedTheme =
    BOARD_THEMES.find((t) => t.id === previewBoardTheme) || BOARD_THEMES[0];
  const selectedSet =
    PIECE_SETS.find((p) => p.id === previewPieceSet) || PIECE_SETS[0];

  const handleEquipPieceSet = (id: string) => {
    sounds.playMove();
    onUpdateProfile({ equippedPieceSet: id });
    setPreviewPieceSet(id);
  };

  const handleUnlockPieceSet = (id: string, price: number) => {
    if (profile.coins < price) {
      sounds.playPuzzleWrong();
      return;
    }
    sounds.playVictory();
    try {
      confetti({ particleCount: 60, spread: 50, origin: { y: 0.6 } });
    } catch {}

    const updatedUnlocked = [...profile.unlockedPieceSets, id];
    onUpdateProfile({
      coins: profile.coins - price,
      unlockedPieceSets: updatedUnlocked,
      equippedPieceSet: id
    });
    setPreviewPieceSet(id);
  };

  const handleEquipBoardTheme = (id: string) => {
    sounds.playMove();
    onUpdateProfile({ equippedBoardTheme: id });
    setPreviewBoardTheme(id);
  };

  const handleUnlockBoardTheme = (id: string, price: number) => {
    if (profile.coins < price) {
      sounds.playPuzzleWrong();
      return;
    }
    sounds.playVictory();
    try {
      confetti({ particleCount: 60, spread: 50, origin: { y: 0.6 } });
    } catch {}

    const updatedUnlocked = [...profile.unlockedBoardThemes, id];
    onUpdateProfile({
      coins: profile.coins - price,
      unlockedBoardThemes: updatedUnlocked,
      equippedBoardTheme: id
    });
    setPreviewBoardTheme(id);
  };

  // Sample mini board arrangement for previewing
  const previewCells: { piece?: { c: 'w' | 'b'; t: PieceType }; isDark: boolean }[] = [
    { piece: { c: 'b', t: 'r' }, isDark: false },
    { piece: { c: 'b', t: 'n' }, isDark: true },
    { piece: { c: 'b', t: 'b' }, isDark: false },
    { piece: { c: 'b', t: 'q' }, isDark: true },
    { piece: { c: 'b', t: 'k' }, isDark: false },
    { piece: { c: 'b', t: 'b' }, isDark: true },

    { piece: { c: 'b', t: 'p' }, isDark: true },
    { piece: { c: 'b', t: 'p' }, isDark: false },
    { isDark: true },
    { isDark: false },
    { piece: { c: 'w', t: 'p' }, isDark: true },
    { piece: { c: 'w', t: 'p' }, isDark: false },

    { piece: { c: 'w', t: 'r' }, isDark: false },
    { piece: { c: 'w', t: 'n' }, isDark: true },
    { piece: { c: 'w', t: 'b' }, isDark: false },
    { piece: { c: 'w', t: 'q' }, isDark: true },
    { piece: { c: 'w', t: 'k' }, isDark: false },
    { piece: { c: 'w', t: 'b' }, isDark: true }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-amber-400">
              <Sparkles className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-white">
              Cosmetic Armory & Customization
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Unlock distinguished piece sets and handcrafted board materials using match coins.
          </p>
        </div>

        {/* Coin Balance Badge */}
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-300 font-bold self-start sm:self-auto">
          <Coins className="w-4 h-4 text-amber-400" />
          <span className="font-mono text-sm">{profile.coins}</span>
          <span className="text-xs uppercase font-sans text-amber-400/80">Coins</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Interactive Live Preview Stage */}
        <div className="lg:col-span-5 bg-[#141d27] border border-[#233346] rounded-2xl p-6 shadow-xl flex flex-col items-center">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-400 mb-1 self-start">
            Live Preview
          </span>
          <h3 className="text-base font-bold text-white mb-4 self-start">
            {selectedSet.name} · {selectedTheme.name}
          </h3>

          {/* Mini 6x3 Demonstration Board */}
          <div
            className="w-full max-w-[340px] aspect-[6/3] grid grid-cols-6 grid-rows-3 rounded-xl overflow-hidden shadow-2xl border-2 border-[#2b3c50]"
            style={{ backgroundColor: selectedTheme.dark }}
          >
            {previewCells.map((cell, idx) => (
              <div
                key={idx}
                className="flex items-center justify-center p-0 relative"
                style={{
                  backgroundColor: cell.isDark ? selectedTheme.dark : selectedTheme.light
                }}
              >
                {cell.piece && (
                  <span
                    className={`text-2xl sm:text-3xl leading-none select-none transition-transform ${
                      cell.piece.c === 'w'
                        ? 'text-[#fbf9f4] drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]'
                        : 'text-[#18181b] drop-shadow-[0_1px_2px_rgba(255,255,255,0.4)]'
                    } ${selectedSet.styleClass || ''}`}
                  >
                    {selectedSet.glyphs[cell.piece.c]?.[cell.piece.t]}
                  </span>
                )}
              </div>
            ))}
          </div>

          <div className="mt-5 w-full bg-[#0f1721] border border-[#1c2938] rounded-xl p-3 text-xs text-slate-300">
            <span className="font-bold text-white block mb-0.5">Style Notes:</span>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              {selectedSet.description} {selectedTheme.description}
            </p>
          </div>
        </div>

        {/* Right Column: Piece Sets & Board Themes Switcher */}
        <div className="lg:col-span-7 bg-[#141d27] border border-[#233346] rounded-2xl p-6 shadow-xl">
          {/* Segmented Filter */}
          <div className="flex items-center gap-2 pb-4 mb-5 border-b border-[#213042]">
            <button
              type="button"
              onClick={() => setActiveTab('pieces')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'pieces'
                  ? 'bg-emerald-600 text-slate-950 shadow-md'
                  : 'bg-[#101720] text-slate-400 hover:text-white border border-[#1e2d3d]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Cosmetic Piece Sets ({PIECE_SETS.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('boards')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'boards'
                  ? 'bg-emerald-600 text-slate-950 shadow-md'
                  : 'bg-[#101720] text-slate-400 hover:text-white border border-[#1e2d3d]'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              Board Materials ({BOARD_THEMES.length})
            </button>
          </div>

          {/* Piece Sets Grid */}
          {activeTab === 'pieces' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {PIECE_SETS.map((set) => {
                const isUnlocked = profile.unlockedPieceSets.includes(set.id);
                const isEquipped = profile.equippedPieceSet === set.id;
                const canAfford = profile.coins >= set.price;

                return (
                  <div
                    key={set.id}
                    onClick={() => setPreviewPieceSet(set.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      previewPieceSet === set.id
                        ? 'bg-emerald-950/20 border-emerald-500/60 shadow-lg'
                        : 'bg-[#101721] border-[#1d2b3b] hover:border-[#2d4257]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold text-white">{set.name}</span>
                        {isEquipped && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                            <Check className="w-3 h-3" /> Equipped
                          </span>
                        )}
                      </div>

                      {/* Preview Glyphs */}
                      <div className="flex items-center gap-2 text-2xl my-2 text-slate-200">
                        <span>{set.previewGlyphs.w}</span>
                        <span>{set.previewGlyphs.b}</span>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-snug mb-3">
                        {set.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#1a2636] flex items-center justify-between">
                      {isUnlocked ? (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEquipPieceSet(set.id);
                          }}
                          disabled={isEquipped}
                          className="w-full py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 disabled:opacity-50 disabled:pointer-events-none"
                        >
                          {isEquipped ? 'Active Set' : 'Equip Piece Set'}
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUnlockPieceSet(set.id, set.price);
                          }}
                          disabled={!canAfford}
                          className="w-full py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 disabled:opacity-40 flex items-center justify-center gap-1.5"
                        >
                          <Lock className="w-3 h-3" />
                          Unlock for {set.price} Coins
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Board Themes Grid */}
          {activeTab === 'boards' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {BOARD_THEMES.map((theme) => {
                const isUnlocked = profile.unlockedBoardThemes.includes(theme.id);
                const isEquipped = profile.equippedBoardTheme === theme.id;
                const canAfford = profile.coins >= theme.price;

                return (
                  <div
                    key={theme.id}
                    onClick={() => setPreviewBoardTheme(theme.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      previewBoardTheme === theme.id
                        ? 'bg-emerald-950/20 border-emerald-500/60 shadow-lg'
                        : 'bg-[#101721] border-[#1d2b3b] hover:border-[#2d4257]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold text-white">{theme.name}</span>
                        {isEquipped && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                            <Check className="w-3 h-3" /> Equipped
                          </span>
                        )}
                      </div>

                      {/* Swatch preview */}
                      <div className="flex items-center gap-1.5 my-2">
                        <div
                          className="w-6 h-6 rounded border border-white/20 shadow-xs"
                          style={{ backgroundColor: theme.light }}
                        />
                        <div
                          className="w-6 h-6 rounded border border-white/20 shadow-xs"
                          style={{ backgroundColor: theme.dark }}
                        />
                        <div
                          className="w-6 h-6 rounded border border-white/20 shadow-xs"
                          style={{ backgroundColor: theme.legal }}
                        />
                      </div>

                      <p className="text-[11px] text-slate-400 leading-snug mb-3">
                        {theme.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#1a2636] flex items-center justify-between">
                      {isUnlocked ? (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEquipBoardTheme(theme.id);
                          }}
                          disabled={isEquipped}
                          className="w-full py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 disabled:opacity-50 disabled:pointer-events-none"
                        >
                          {isEquipped ? 'Active Board' : 'Equip Board'}
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUnlockBoardTheme(theme.id, theme.price);
                          }}
                          disabled={!canAfford}
                          className="w-full py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 disabled:opacity-40 flex items-center justify-center gap-1.5"
                        >
                          <Lock className="w-3 h-3" />
                          Unlock for {theme.price} Coins
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
