import React, { useState } from 'react';
import { GameState, PieceCode, PieceColor, PieceType, PlayerProfile } from '../types/chess';
import {
  colorOf,
  coord,
  FILES,
  idx,
  initialStandardState,
  parseFEN,
  stateToFEN,
  typeOf
} from '../utils/chessEngine';
import { PIECE_SETS } from '../data/cosmetics';
import { sounds } from '../utils/soundEffects';
import { Play, RotateCcw, Trash2, Copy, Check, Terminal } from 'lucide-react';

interface BoardEditorViewProps {
  profile: PlayerProfile;
  onPlayCustomPosition: (customState: GameState) => void;
}

export const BoardEditorView: React.FC<BoardEditorViewProps> = ({
  profile,
  onPlayCustomPosition
}) => {
  const [board, setBoard] = useState<(PieceCode | null)[]>(
    () => initialStandardState().board
  );
  const [turn, setTurn] = useState<PieceColor>('w');
  const [castle, setCastle] = useState({ K: true, Q: true, k: true, q: true });
  const [activeTool, setActiveTool] = useState<'place' | 'erase'>('place');
  const [selectedPalettePiece, setSelectedPalettePiece] = useState<PieceCode>('wp');
  const [fenInput, setFenInput] = useState(() => stateToFEN(initialStandardState()));
  const [copied, setCopied] = useState(false);

  const currentPieceSet =
    PIECE_SETS.find((p) => p.id === profile.equippedPieceSet) || PIECE_SETS[0];

  const updateBoardSquare = (i: number) => {
    sounds.playMove();
    const newBoard = board.slice();
    if (activeTool === 'erase') {
      newBoard[i] = null;
    } else {
      newBoard[i] = selectedPalettePiece;
    }
    setBoard(newBoard);
    syncFEN(newBoard, turn, castle);
  };

  const syncFEN = (
    b: (PieceCode | null)[],
    t: PieceColor,
    c: { K: boolean; Q: boolean; k: boolean; q: boolean }
  ) => {
    const s: GameState = {
      board: b,
      turn: t,
      castle: c,
      ep: null,
      halfmove: 0,
      fullmove: 1
    };
    setFenInput(stateToFEN(s));
  };

  const handleApplyFEN = () => {
    try {
      const parsed = parseFEN(fenInput);
      setBoard(parsed.board);
      setTurn(parsed.turn);
      setCastle(parsed.castle);
      sounds.playSuccess();
    } catch {
      sounds.playPuzzleWrong();
    }
  };

  const handleClearBoard = () => {
    sounds.playMove();
    const empty = Array(64).fill(null);
    setBoard(empty);
    syncFEN(empty, turn, castle);
  };

  const handleResetStandard = () => {
    sounds.playMove();
    const standard = initialStandardState();
    setBoard(standard.board);
    setTurn(standard.turn);
    setCastle(standard.castle);
    setFenInput(stateToFEN(standard));
  };

  const handleCopyFEN = () => {
    navigator.clipboard?.writeText(fenInput).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleLaunchGame = () => {
    const customState: GameState = {
      board: board.slice(),
      turn,
      castle,
      ep: null,
      halfmove: 0,
      fullmove: 1
    };
    sounds.playVictory();
    onPlayCustomPosition(customState);
  };

  const pieceTypes: PieceType[] = ['k', 'q', 'r', 'b', 'n', 'p'];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Interactive Editor Board */}
      <div className="lg:col-span-7 flex flex-col items-center">
        <div className="w-full max-w-[620px] mb-3 flex items-center justify-between bg-[#141d27] border border-[#233346] rounded-xl px-4 py-2.5 shadow-md">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-bold text-slate-400">Turn to Move:</span>
            <div className="flex items-center gap-1 bg-[#0f1721] p-1 rounded-lg border border-[#1d2b3b]">
              <button
                type="button"
                onClick={() => {
                  setTurn('w');
                  syncFEN(board, 'w', castle);
                }}
                className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
                  turn === 'w' ? 'bg-slate-200 text-slate-950' : 'text-slate-400'
                }`}
              >
                White ♔
              </button>
              <button
                type="button"
                onClick={() => {
                  setTurn('b');
                  syncFEN(board, 'b', castle);
                }}
                className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
                  turn === 'b' ? 'bg-slate-800 text-white' : 'text-slate-400'
                }`}
              >
                Black ♚
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTool('place')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                activeTool === 'place'
                  ? 'bg-emerald-600 text-slate-950'
                  : 'bg-[#182330] text-slate-400 hover:text-white'
              }`}
            >
              Place
            </button>
            <button
              type="button"
              onClick={() => setActiveTool('erase')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                activeTool === 'erase'
                  ? 'bg-rose-600 text-white'
                  : 'bg-[#182330] text-slate-400 hover:text-white'
              }`}
            >
              Erase
            </button>
          </div>
        </div>

        {/* Board */}
        <div className="w-full max-w-[620px] aspect-square rounded-2xl p-2 sm:p-3 bg-[#131b24] border border-[#223142] shadow-2xl">
          <div className="w-full h-full grid grid-cols-8 grid-rows-8 rounded-xl overflow-hidden shadow-inner bg-[#568b55]">
            {Array.from({ length: 64 }).map((_, sqIdx) => {
              const file = sqIdx % 8;
              const rank = 7 - Math.floor(sqIdx / 8);
              const isLight = (file + rank) % 2 === 0;
              const piece = board[sqIdx];

              return (
                <button
                  key={sqIdx}
                  type="button"
                  onClick={() => updateBoardSquare(sqIdx)}
                  className={`aspect-square flex items-center justify-center p-0 m-0 border-0 cursor-pointer transition-colors relative hover:brightness-110 ${
                    isLight ? 'bg-[#eaefe3]' : 'bg-[#568b55]'
                  }`}
                >
                  {piece && (
                    <span
                      className={`text-[clamp(26px,5.5vw,52px)] leading-none select-none ${
                        colorOf(piece) === 'w'
                          ? 'text-[#fbf9f4] drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]'
                          : 'text-[#18181b] drop-shadow-[0_1px_2px_rgba(255,255,255,0.4)]'
                      } ${currentPieceSet.styleClass || ''}`}
                    >
                      {currentPieceSet.glyphs[colorOf(piece)!]?.[typeOf(piece)!]}
                    </span>
                  )}
                  {file === 0 && (
                    <span className="absolute top-0.5 left-1 text-[9px] font-bold text-black/50 select-none">
                      {rank + 1}
                    </span>
                  )}
                  {rank === 0 && (
                    <span className="absolute bottom-0.5 right-1 text-[9px] font-bold text-black/50 select-none">
                      {FILES[file]}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Bar */}
        <div className="w-full max-w-[620px] grid grid-cols-3 gap-2 mt-3">
          <button
            type="button"
            onClick={handleClearBoard}
            className="py-2.5 px-3 rounded-xl bg-rose-950/20 hover:bg-rose-900/30 border border-rose-700/40 text-rose-300 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear All
          </button>
          <button
            type="button"
            onClick={handleResetStandard}
            className="py-2.5 px-3 rounded-xl bg-[#141d27] hover:bg-[#1d2a3a] border border-[#223347] text-slate-300 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Standard
          </button>
          <button
            type="button"
            onClick={handleLaunchGame}
            className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Play Custom
          </button>
        </div>
      </div>

      {/* Piece Palette & FEN Panel */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Piece Palette Card */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-400 mb-3 block">
            Piece Placement Palette
          </span>

          <div className="space-y-3">
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                White Pieces
              </span>
              <div className="flex items-center gap-2">
                {pieceTypes.map((t) => {
                  const code: PieceCode = `w${t}`;
                  return (
                    <button
                      key={code}
                      type="button"
                      onClick={() => {
                        setSelectedPalettePiece(code);
                        setActiveTool('place');
                      }}
                      className={`w-11 h-11 rounded-xl border flex items-center justify-center text-2xl transition-all cursor-pointer ${
                        selectedPalettePiece === code && activeTool === 'place'
                          ? 'bg-emerald-950/40 border-emerald-500 scale-105 shadow-md'
                          : 'bg-[#101720] border-[#1d2b3b] hover:bg-[#182330]'
                      }`}
                    >
                      <span className="text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                        {currentPieceSet.glyphs.w[t]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Black Pieces
              </span>
              <div className="flex items-center gap-2">
                {pieceTypes.map((t) => {
                  const code: PieceCode = `b${t}`;
                  return (
                    <button
                      key={code}
                      type="button"
                      onClick={() => {
                        setSelectedPalettePiece(code);
                        setActiveTool('place');
                      }}
                      className={`w-11 h-11 rounded-xl border flex items-center justify-center text-2xl transition-all cursor-pointer ${
                        selectedPalettePiece === code && activeTool === 'place'
                          ? 'bg-emerald-950/40 border-emerald-500 scale-105 shadow-md'
                          : 'bg-[#101720] border-[#1d2b3b] hover:bg-[#182330]'
                      }`}
                    >
                      <span className="text-slate-300 drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                        {currentPieceSet.glyphs.b[t]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* FEN Notation Exporter/Loader */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs uppercase font-bold tracking-wider text-slate-400 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              FEN String Position
            </span>
            <button
              type="button"
              onClick={handleCopyFEN}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold cursor-pointer"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>

          <textarea
            rows={3}
            value={fenInput}
            onChange={(e) => setFenInput(e.target.value)}
            className="w-full bg-[#0f1721] border border-[#1c2938] rounded-xl p-3 text-xs font-mono text-slate-300 focus:outline-none focus:border-emerald-500/60 resize-none mb-3"
            placeholder="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
          />

          <button
            type="button"
            onClick={handleApplyFEN}
            className="w-full py-2.5 rounded-xl bg-[#1c2938] hover:bg-[#25364a] text-slate-200 border border-[#2d4157] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            Apply FEN Position
          </button>
        </div>
      </div>
    </div>
  );
};
