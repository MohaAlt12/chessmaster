import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { ChessBoard } from './ChessBoard';
import { PlayerProfile, ChessMove, PieceType } from '../types/chess';
import { CHESS_PUZZLES } from '../data/puzzles';
import {
  applyMove,
  coord,
  legalMoves,
  parseCoord,
  parseFEN
} from '../utils/chessEngine';
import { sounds } from '../utils/soundEffects';
import { Zap, Heart, Trophy, RotateCcw, Play, CheckCircle, XCircle } from 'lucide-react';

interface PuzzleRushViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
}

export const PuzzleRushView: React.FC<PuzzleRushViewProps> = ({
  profile,
  onUpdateProfile
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [mode, setMode] = useState<'survival' | 'blitz'>('survival');
  const [score, setScore] = useState(0);
  const [strikes, setStrikes] = useState(0); // 3 strikes allowed in survival
  const [timeLeft, setTimeLeft] = useState(180); // 3 minutes in blitz
  const [puzzleQueue, setPuzzleQueue] = useState(() => [...CHESS_PUZZLES].sort(() => Math.random() - 0.5));
  const [currentIdx, setCurrentIdx] = useState(0);
  const [combo, setCombo] = useState(0);

  const currentPuzzle = puzzleQueue[currentIdx] || puzzleQueue[0];
  const [gameState, setGameState] = useState(() => parseFEN(currentPuzzle.fen));
  const [selectedSquare, setSelectedSquare] = useState<number | null>(null);
  const [activeLegals, setActiveLegals] = useState<ChessMove[]>([]);
  const [lastMove, setLastMove] = useState<{ from: number; to: number } | null>(null);
  const [moveStep, setMoveStep] = useState(0);
  const [pendingPromotionMove, setPendingPromotionMove] = useState<ChessMove | null>(null);
  const [rushOver, setRushOver] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Timer countdown for Blitz mode
  useEffect(() => {
    if (isPlaying && mode === 'blitz' && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleGameOver();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, mode, timeLeft]);

  // Load puzzle state when index changes
  useEffect(() => {
    if (currentPuzzle) {
      setGameState(parseFEN(currentPuzzle.fen));
      setSelectedSquare(null);
      setActiveLegals([]);
      setLastMove(null);
      setMoveStep(0);
      setPendingPromotionMove(null);
    }
  }, [currentIdx, currentPuzzle]);

  const startRush = (selectedMode: 'survival' | 'blitz') => {
    const shuffled = [...CHESS_PUZZLES].sort(() => Math.random() - 0.5);
    setPuzzleQueue(shuffled);
    setCurrentIdx(0);
    setScore(0);
    setStrikes(0);
    setCombo(0);
    setTimeLeft(180);
    setMode(selectedMode);
    setIsPlaying(true);
    setRushOver(false);
  };

  const handleGameOver = () => {
    setIsPlaying(false);
    setRushOver(true);
    if (timerRef.current) clearInterval(timerRef.current);

    // Check if new high score
    if (score > profile.puzzleRushHighScore) {
      sounds.playVictory();
      try {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      } catch {}
      onUpdateProfile({
        puzzleRushHighScore: score,
        coins: profile.coins + score * 10
      });
    } else {
      sounds.playPuzzleWrong();
      onUpdateProfile({
        coins: profile.coins + score * 5
      });
    }
  };

  const handleSquareClick = (sq: number) => {
    if (!isPlaying || rushOver) return;

    const piece = gameState.board[sq];

    if (selectedSquare !== null) {
      const targetMove = activeLegals.find((m) => m.to === sq);
      if (targetMove) {
        if (targetMove.promotion) {
          setPendingPromotionMove(targetMove);
          return;
        }
        executePlayerMove(targetMove);
        return;
      }
    }

    if (piece && piece[0] === gameState.turn) {
      setSelectedSquare(sq);
      setActiveLegals(legalMoves(gameState, sq));
    } else {
      setSelectedSquare(null);
      setActiveLegals([]);
    }
  };

  const handlePromotionChoice = (promo: PieceType) => {
    if (!pendingPromotionMove) return;
    const moveWithPromo = { ...pendingPromotionMove, promote: promo };
    setPendingPromotionMove(null);
    executePlayerMove(moveWithPromo);
  };

  const executePlayerMove = (move: ChessMove) => {
    const expectedUci = currentPuzzle.solutionUci[moveStep];
    const fromCoord = coord(move.from);
    const toCoord = coord(move.to);
    const playedUci = `${fromCoord}${toCoord}${move.promote || ''}`;

    const isCorrect = playedUci.slice(0, 4) === expectedUci.slice(0, 4);

    if (!isCorrect) {
      sounds.playPuzzleWrong();
      setCombo(0);

      if (mode === 'survival') {
        const nextStrikes = strikes + 1;
        setStrikes(nextStrikes);
        if (nextStrikes >= 3) {
          handleGameOver();
          return;
        }
      }

      // Skip to next puzzle on mistake in rush mode
      advanceToNextPuzzle(false);
      return;
    }

    // Correct move!
    sounds.playMove();
    const nextState = applyMove(gameState, move, move.promote || 'q');
    setGameState(nextState);
    setLastMove({ from: move.from, to: move.to });
    setSelectedSquare(null);
    setActiveLegals([]);

    const nextStep = moveStep + 1;
    setMoveStep(nextStep);

    // If puzzle solved
    if (nextStep >= currentPuzzle.solutionUci.length) {
      handlePuzzleSolved();
      return;
    }

    // Opponent response
    setTimeout(() => {
      const oppUci = currentPuzzle.solutionUci[nextStep];
      if (!oppUci) {
        handlePuzzleSolved();
        return;
      }
      const oppFrom = parseCoord(oppUci.slice(0, 2));
      const oppTo = parseCoord(oppUci.slice(2, 4));
      const oppPromo = (oppUci[4] as PieceType) || 'q';

      const oppMove: ChessMove = {
        from: oppFrom,
        to: oppTo,
        promotion: oppUci.length === 5,
        promote: oppPromo
      };

      sounds.playCapture();
      const afterOpp = applyMove(nextState, oppMove, oppPromo);
      setGameState(afterOpp);
      setLastMove({ from: oppFrom, to: oppTo });
      setMoveStep(nextStep + 1);

      if (nextStep + 1 >= currentPuzzle.solutionUci.length) {
        handlePuzzleSolved();
      }
    }, 350);
  };

  const handlePuzzleSolved = () => {
    sounds.playSuccess();
    setScore((prev) => prev + 1);
    setCombo((prev) => prev + 1);
    advanceToNextPuzzle(true);
  };

  const advanceToNextPuzzle = (solved: boolean) => {
    setTimeout(() => {
      const nextIdx = (currentIdx + 1) % puzzleQueue.length;
      setCurrentIdx(nextIdx);
    }, 400);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Board Column */}
      <div className="lg:col-span-7 flex flex-col items-center">
        <ChessBoard
          state={gameState}
          selectedSquare={selectedSquare}
          legalMoves={activeLegals}
          lastMove={lastMove}
          flipped={currentPuzzle.playerColor === 'b'}
          activePieceSetId={profile.equippedPieceSet}
          activeBoardThemeId={profile.equippedBoardTheme}
          onSquareClick={handleSquareClick}
          onPromoteChoice={handlePromotionChoice}
          pendingPromotionMove={pendingPromotionMove}
          disabled={!isPlaying || rushOver}
        />

        {/* Live rush status bar */}
        {isPlaying && (
          <div className="mt-4 w-full max-w-[620px] bg-[#141d27] border border-[#233346] rounded-xl p-3 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-xs uppercase font-bold text-slate-400">Streak Combo</span>
              <span className="text-base font-black text-amber-400">🔥 {combo}x</span>
            </div>

            <div className="text-center text-xs text-slate-300">
              <span className="font-bold text-white">{currentPuzzle.title}</span>
              <span className="text-slate-500 ml-1.5">({currentPuzzle.difficulty})</span>
            </div>

            <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
              <CheckCircle className="w-4 h-4" />
              <span>{score} Solved</span>
            </div>
          </div>
        )}
      </div>

      {/* Control / Stats Column */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Score & Life Tracker Card */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#213042]">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Zap className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Puzzle Rush Sprint</h3>
                <span className="text-xs text-slate-400">Fast Tactical Puzzles</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs uppercase font-semibold text-slate-400 block">Personal Best</span>
              <span className="text-lg font-black text-amber-400 flex items-center gap-1 justify-end">
                <Trophy className="w-4 h-4" />
                {profile.puzzleRushHighScore}
              </span>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-2.5 mb-5 text-center">
            <div className="bg-[#101720] border border-[#1d2b3b] p-3 rounded-xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Solved</span>
              <strong className="text-2xl font-black text-white">{score}</strong>
            </div>

            <div className="bg-[#101720] border border-[#1d2b3b] p-3 rounded-xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                {mode === 'survival' ? 'Lives Left' : 'Time Left'}
              </span>
              {mode === 'survival' ? (
                <div className="flex items-center justify-center gap-1 pt-1">
                  {[0, 1, 2].map((i) => (
                    <Heart
                      key={i}
                      className={`w-5 h-5 ${
                        i < 3 - strikes ? 'text-rose-500 fill-rose-500' : 'text-slate-600'
                      }`}
                    />
                  ))}
                </div>
              ) : (
                <strong className="text-2xl font-black text-cyan-400 font-mono">
                  {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                </strong>
              )}
            </div>

            <div className="bg-[#101720] border border-[#1d2b3b] p-3 rounded-xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Combo Multiplier</span>
              <strong className="text-2xl font-black text-emerald-400">{combo}x</strong>
            </div>
          </div>

          {/* Play / Restart Controls */}
          {!isPlaying && !rushOver && (
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => startRush('survival')}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 cursor-pointer transition-all active:scale-[0.98]"
              >
                <Play className="w-4 h-4 fill-current" />
                Play Survival Mode (3 Strikes)
              </button>
              <button
                type="button"
                onClick={() => startRush('blitz')}
                className="w-full py-3 px-4 rounded-xl bg-[#1c2938] hover:bg-[#25364a] text-slate-200 border border-[#2d4157] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Zap className="w-4 h-4 text-amber-400" />
                Play 3-Minute Blitz Sprint
              </button>
            </div>
          )}

          {rushOver && (
            <div className="bg-[#101722] border border-[#223547] rounded-xl p-4 text-center">
              <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block mb-1">
                Run Concluded
              </span>
              <div className="text-2xl font-black text-white mb-1">
                You solved {score} puzzles!
              </div>
              <p className="text-xs text-slate-400 mb-4">
                {score >= profile.puzzleRushHighScore
                  ? "🔥 NEW HIGH SCORE! Congratulations!"
                  : `Personal Best: ${profile.puzzleRushHighScore}`}
              </p>
              <button
                type="button"
                onClick={() => startRush(mode)}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
              >
                <RotateCcw className="w-4 h-4" />
                Play Again Now
              </button>
            </div>
          )}
        </div>

        {/* Tips & Repetitive Fun Info */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl text-xs text-slate-300 leading-relaxed">
          <strong className="text-white block mb-1.5 flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-400" />
            Tactical Sprint Rules
          </strong>
          <ul className="space-y-1.5 text-slate-400 list-disc list-inside">
            <li>Solve as many puzzles in succession as possible.</li>
            <li>In Survival mode, you have 3 lives before the run ends.</li>
            <li>Each solve earns coins to unlock cosmetic piece sets!</li>
            <li>Building combos boosts your end-of-run coin bonuses.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
