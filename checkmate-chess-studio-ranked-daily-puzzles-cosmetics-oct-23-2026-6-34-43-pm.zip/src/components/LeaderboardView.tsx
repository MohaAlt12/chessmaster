import React, { useState } from 'react';
import { PlayerProfile, RankTier } from '../types/chess';
import {
  BOT_PERSONALITIES,
  getTierForRating,
  INITIAL_LEADERBOARD,
  TIER_CONFIG
} from '../data/leaderboard';
import { Trophy, Swords, Flame, Crown, Shield, TrendingUp } from 'lucide-react';

interface LeaderboardViewProps {
  profile: PlayerProfile;
  onChallengeBot: (botId: string) => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  profile,
  onChallengeBot
}) => {
  const [filter, setFilter] = useState<'all' | 'bots' | 'players'>('all');

  const playerTier = getTierForRating(profile.rating);
  const currentTierInfo = TIER_CONFIG[playerTier];

  // Combine player with simulated leaderboard list
  const fullLeaderboard = [
    ...INITIAL_LEADERBOARD.map((p) => ({ ...p, isUser: false })),
    {
      id: 'user-profile',
      name: `${profile.name} (You)`,
      avatar: '👑',
      rating: profile.rating,
      tier: playerTier,
      isUser: true,
      wins: profile.rankedWins,
      losses: profile.rankedLosses,
      draws: profile.rankedDraws,
      streak: profile.puzzleStreak
    }
  ].sort((a, b) => b.rating - a.rating);

  const filteredList = fullLeaderboard.filter((entry) => {
    if (filter === 'bots') return !!entry.botId;
    if (filter === 'players') return !entry.botId;
    return true;
  });

  const totalMatches = profile.rankedWins + profile.rankedLosses + profile.rankedDraws;
  const winRate = totalMatches > 0 ? Math.round((profile.rankedWins / totalMatches) * 100) : 0;

  // Next tier progress
  const nextTierPoints =
    currentTierInfo.maxRating === 3000
      ? 100
      : Math.max(0, currentTierInfo.maxRating - profile.rating);
  const tierProgressPct = Math.min(
    100,
    Math.max(
      0,
      Math.round(
        ((profile.rating - currentTierInfo.minRating) /
          (currentTierInfo.maxRating - currentTierInfo.minRating)) *
          100
      )
    )
  );

  return (
    <div className="space-y-6">
      {/* Top Banner: Personal Tier Status */}
      <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-5 flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-yellow-500/10 border border-amber-500/30 flex items-center justify-center text-3xl shadow-inner shrink-0">
              {currentTierInfo.icon}
            </div>
            <div>
              <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400 block mb-0.5">
                Current Division
              </span>
              <h2 className="text-2xl font-black text-white flex items-center gap-2">
                {playerTier} Tier
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                {profile.rating} Elo Rating
              </span>
            </div>
          </div>

          {/* Tier Progress Bar */}
          <div className="md:col-span-4 bg-[#0f1721] border border-[#1c2938] rounded-xl p-4">
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="text-slate-400 font-medium">Rank Progression</span>
              <span className="text-emerald-400 font-bold font-mono">
                {tierProgressPct}%
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                style={{ width: `${tierProgressPct}%` }}
              />
            </div>
            <div className="text-[11px] text-slate-400 mt-2 flex justify-between">
              <span>{currentTierInfo.minRating} Elo</span>
              <span>
                {currentTierInfo.maxRating === 3000
                  ? 'Grandmaster Peak'
                  : `${nextTierPoints} Elo to rank up`}
              </span>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="md:col-span-3 grid grid-cols-3 gap-2 text-center">
            <div className="bg-[#0f1721] border border-[#1c2938] p-3 rounded-xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                Win Rate
              </span>
              <span className="text-base font-black text-emerald-400">{winRate}%</span>
            </div>
            <div className="bg-[#0f1721] border border-[#1c2938] p-3 rounded-xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                W / L / D
              </span>
              <span className="text-xs font-mono font-bold text-slate-200">
                {profile.rankedWins}/{profile.rankedLosses}/{profile.rankedDraws}
              </span>
            </div>
            <div className="bg-[#0f1721] border border-[#1c2938] p-3 rounded-xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                Streak
              </span>
              <span className="text-base font-black text-amber-400 flex items-center justify-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-amber-400" />
                {profile.puzzleStreak}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Leaderboard Table Container */}
      <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#213042] mb-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              Global Grand Prix Leaderboard
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Ranked ladder dynamically calculated via FIDE Elo rating formula.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1 bg-[#0f1721] p-1 rounded-xl border border-[#1d2b3b]">
            {(['all', 'bots', 'players'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setFilter(tab)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize transition-colors cursor-pointer ${
                  filter === tab
                    ? 'bg-emerald-600 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1f2d3d] text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                <th className="py-3 px-3">Rank</th>
                <th className="py-3 px-3">Player / Bot</th>
                <th className="py-3 px-3">Tier</th>
                <th className="py-3 px-3">Elo Rating</th>
                <th className="py-3 px-3">Record (W-L-D)</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182330]">
              {filteredList.map((player, rankIdx) => {
                const tierInfo = TIER_CONFIG[player.tier];
                const isUser = player.isUser;

                return (
                  <tr
                    key={player.id}
                    className={`transition-colors ${
                      isUser
                        ? 'bg-emerald-950/20 font-bold'
                        : 'hover:bg-white/5'
                    }`}
                  >
                    <td className="py-3.5 px-3 font-mono font-bold">
                      {rankIdx + 1 === 1 ? (
                        <span className="text-amber-400">🥇 #1</span>
                      ) : rankIdx + 1 === 2 ? (
                        <span className="text-slate-300">🥈 #2</span>
                      ) : rankIdx + 1 === 3 ? (
                        <span className="text-amber-600">🥉 #3</span>
                      ) : (
                        <span className="text-slate-400">#{rankIdx + 1}</span>
                      )}
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl shrink-0">{player.avatar}</span>
                        <div>
                          <span
                            className={`font-semibold block ${
                              isUser ? 'text-emerald-400' : 'text-white'
                            }`}
                          >
                            {player.name}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {player.botId ? 'Calibrated Bot' : 'Challenger'}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${tierInfo.badgeBg} ${tierInfo.badgeBorder}`}
                      >
                        {tierInfo.icon} {player.tier}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 font-mono text-sm font-bold text-amber-400">
                      {player.rating}
                    </td>

                    <td className="py-3.5 px-3 font-mono text-slate-300">
                      <span className="text-emerald-400">{player.wins}W</span> ·{' '}
                      <span className="text-rose-400">{player.losses}L</span> ·{' '}
                      <span className="text-slate-400">{player.draws}D</span>
                    </td>

                    <td className="py-3.5 px-3 text-right">
                      {player.botId ? (
                        <button
                          type="button"
                          onClick={() => onChallengeBot(player.botId!)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold flex items-center gap-1.5 ml-auto cursor-pointer transition-colors"
                        >
                          <Swords className="w-3.5 h-3.5" />
                          Challenge
                        </button>
                      ) : isUser ? (
                        <span className="text-slate-500 text-[11px] italic">You</span>
                      ) : (
                        <span className="text-slate-500 text-[11px]">Ranked</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
