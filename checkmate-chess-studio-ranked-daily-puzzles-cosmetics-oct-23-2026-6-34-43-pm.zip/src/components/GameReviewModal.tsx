import React from 'react';
import { MoveLogEntry, PieceColor } from '../types/chess';
import { Trophy, Swords, RotateCcw, X, Award, TrendingUp, TrendingDown } from 'lucide-react';

interface GameReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRematch: () => void;
  winner: PieceColor | null;
  reason: string;
  movesCount: number;
  playerMover: PieceColor;
  moveLog: MoveLogEntry[];
  eloChange: number;
}

export const GameReviewModal: React.FC<GameReviewModalProps> = ({
  isOpen,
  onClose,
  onRematch,
  winner,
  reason,
  movesCount,
  playerMover,
  moveLog,
  eloChange
}) => {
  if (!isOpen) return null;

  const isPlayerWin = winner === playerMover;
  const isDraw = winner === null;

  // Calculate move quality stats
  const playerMoves = moveLog.filter((m) => m.mover === playerMover);
  const botMoves = moveLog.filter((m) => m.mover !== playerMover);

  const getAccuracy = (entries: MoveLogEntry[]) => {
    if (entries.length === 0) return 90;
    const points: Record<string, number> = {
      brilliant: 100,
      good: 90,
      inaccuracy: 60,
      mistake: 30,
      blunder: 0
    };
    const total = entries.reduce(
      (sum, m) => sum + (points[m.cls || 'good'] ?? 80),
      0
    );
    return Math.min(100, Math.max(10, Math.round(total / entries.length)));
  };

  const playerAccuracy = getAccuracy(playerMoves);
  const botAccuracy = getAccuracy(botMoves);

  const getCounts = (entries: MoveLogEntry[]) => {
    const counts = { brilliant: 0, good: 0, inaccuracy: 0, mistake: 0, blunder: 0 };
    entries.forEach((m) => {
      if (m.cls && counts[m.cls] !== undefined) {
        counts[m.cls]++;
      } else {
        counts.good++;
      }
    });
    return counts;
  };

  const playerCounts = getCounts(playerMoves);
  const botCounts = getCounts(botMoves);

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-[#182332] to-[#101720] border border-[#26374a] rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Verdict Banner */}
        <div className="text-center pt-2 pb-4">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-3 bg-gradient-to-tr from-amber-500/20 to-emerald-500/20 border border-amber-500/30 flex items-center justify-center text-4xl shadow-inner">
            {isPlayerWin ? '🏆' : isDraw ? '🤝' : '⚔️'}
          </div>

          <span className="text-[11px] font-extrabold uppercase tracking-widest text-emerald-400 block mb-1">
            {reason}
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white mb-1">
            {isPlayerWin ? 'Victory!' : isDraw ? 'Draw Agreement' : 'Defeat'}
          </h2>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold mt-1 bg-[#121b26] border border-[#202e3f]">
            {eloChange >= 0 ? (
              <span className="text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />+{eloChange} Elo Rating
              </span>
            ) : (
              <span className="text-rose-400 flex items-center gap-1">
                <TrendingDown className="w-3.5 h-3.5" />
                {eloChange} Elo Rating
              </span>
            )}
          </div>
        </div>

        {/* Accuracy Comparison */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-[#121b26] border border-[#202e3f] rounded-2xl p-3.5 text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              Your Accuracy
            </span>
            <span className="text-2xl font-black text-emerald-400 block mb-1">
              {playerAccuracy}%
            </span>
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-semibold text-slate-400">
              <span className="text-cyan-400 font-bold">★{playerCounts.brilliant}</span>
              <span className="text-emerald-400">✓{playerCounts.good}</span>
              <span className="text-rose-400">??{playerCounts.blunder}</span>
            </div>
          </div>

          <div className="bg-[#121b26] border border-[#202e3f] rounded-2xl p-3.5 text-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              Bot Accuracy
            </span>
            <span className="text-2xl font-black text-slate-200 block mb-1">
              {botAccuracy}%
            </span>
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-semibold text-slate-400">
              <span className="text-cyan-400 font-bold">★{botCounts.brilliant}</span>
              <span className="text-emerald-400">✓{botCounts.good}</span>
              <span className="text-rose-400">??{botCounts.blunder}</span>
            </div>
          </div>
        </div>

        {/* Match Details */}
        <div className="bg-[#101721] border border-[#1b2736] rounded-xl p-3.5 mb-5 flex items-center justify-between text-xs text-slate-300">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Moves Played</span>
            <strong className="text-white font-mono">{Math.ceil(movesCount / 2)} moves</strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Opening Phase</span>
            <strong className="text-white font-mono">10 moves</strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Result</span>
            <strong className="text-emerald-400 font-mono">
              {isPlayerWin ? '1 - 0' : isDraw ? '½ - ½' : '0 - 1'}
            </strong>
          </div>
        </div>

        {/* Modal Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={onClose}
            className="py-3 px-4 rounded-xl bg-[#1c2938] hover:bg-[#25364a] text-slate-200 border border-[#2d4157] font-bold text-xs cursor-pointer transition-colors"
          >
            Review Board
          </button>
          <button
            type="button"
            onClick={onRematch}
            className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Play Rematch
          </button>
        </div>
      </div>
    </div>
  );
};
