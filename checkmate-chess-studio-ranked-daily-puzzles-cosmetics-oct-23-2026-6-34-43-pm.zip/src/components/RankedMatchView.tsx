import React, { useState, useEffect, useRef } from 'react';
import { ChessBoard } from './ChessBoard';
import {
  BotPersonality,
  ChessMove,
  GameState,
  MoveLogEntry,
  MoveQuality,
  PieceColor,
  PieceType,
  PlayerProfile
} from '../types/chess';
import { BOT_PERSONALITIES, calculateEloDelta, TIER_CONFIG } from '../data/leaderboard';
import {
  applyMove,
  chooseEngineMove,
  cloneState,
  coord,
  evaluateBoard,
  evaluatePlayedMove,
  inCheck,
  initialStandardState,
  legalMoves,
  opposite,
  positionKey,
  sanFor,
  terminalState
} from '../utils/chessEngine';
import { sounds } from '../utils/soundEffects';
import {
  RotateCcw,
  Flag,
  Handshake,
  Lightbulb,
  ArrowUpDown,
  Volume2,
  VolumeX,
  Swords,
  Clock,
  Gauge
} from 'lucide-react';

interface RankedMatchViewProps {
  profile: PlayerProfile;
  initialBotId?: string;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
  onOpenReviewModal: (reviewData: {
    winner: PieceColor | null;
    reason: string;
    movesCount: number;
    playerMover: PieceColor;
    moveLog: MoveLogEntry[];
    eloChange: number;
  }) => void;
}

export const RankedMatchView: React.FC<RankedMatchViewProps> = ({
  profile,
  initialBotId,
  onUpdateProfile,
  onOpenReviewModal
}) => {
  const [selectedBotId, setSelectedBotId] = useState<string>(
    initialBotId || 'bot-leo'
  );
  const activeBot =
    BOT_PERSONALITIES.find((b) => b.id === selectedBotId) ||
    BOT_PERSONALITIES[2];

  const [playerColor, setPlayerColor] = useState<PieceColor>('w');
  const [clockMode, setClockMode] = useState<'casual' | 'blitz' | 'rapid'>('rapid');
  const [whiteTime, setWhiteTime] = useState(600); // 10 mins
  const [blackTime, setBlackTime] = useState(600);
  const [isGameActive, setIsGameActive] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [thinking, setThinking] = useState(false);

  const [gameState, setGameState] = useState<GameState>(() => initialStandardState());
  const [selectedSquare, setSelectedSquare] = useState<number | null>(null);
  const [activeLegals, setActiveLegals] = useState<ChessMove[]>([]);
  const [lastMove, setLastMove] = useState<{ from: number; to: number } | null>(null);
  const [moveLog, setMoveLog] = useState<MoveLogEntry[]>([]);
  const [positionCounts, setPositionCounts] = useState<Record<string, number>>({});
  const [flipped, setFlipped] = useState(false);
  const [pendingPromotionMove, setPendingPromotionMove] = useState<ChessMove | null>(null);
  const [hintMove, setHintMove] = useState<ChessMove | null>(null);

  const clockIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize new match
  const startNewMatch = (bot = activeBot, color = playerColor, timeChoice = clockMode) => {
    const fresh = initialStandardState();
    setGameState(fresh);
    setSelectedSquare(null);
    setActiveLegals([]);
    setLastMove(null);
    setMoveLog([]);
    setGameOver(false);
    setThinking(false);
    setHintMove(null);
    setPendingPromotionMove(null);

    const initialSecs = timeChoice === 'blitz' ? 180 : timeChoice === 'rapid' ? 600 : 99999;
    setWhiteTime(initialSecs);
    setBlackTime(initialSecs);

    const pCounts: Record<string, number> = {};
    pCounts[positionKey(fresh)] = 1;
    setPositionCounts(pCounts);

    setFlipped(color === 'b');
    setIsGameActive(true);

    // If bot plays White, trigger bot move
    if (color === 'b') {
      triggerBotMove(fresh, bot);
    }
  };

  useEffect(() => {
    startNewMatch(activeBot, playerColor, clockMode);
    return () => {
      if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
    };
  }, [selectedBotId]);

  // Clocks handler
  useEffect(() => {
    if (!isGameActive || gameOver || clockMode === 'casual') {
      if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
      return;
    }

    clockIntervalRef.current = setInterval(() => {
      if (gameState.turn === 'w') {
        setWhiteTime((prev) => {
          if (prev <= 1) {
            handleTimeout('w');
            return 0;
          }
          return prev - 1;
        });
      } else {
        setBlackTime((prev) => {
          if (prev <= 1) {
            handleTimeout('b');
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => {
      if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
    };
  }, [isGameActive, gameOver, gameState.turn, clockMode]);

  const handleTimeout = (loser: PieceColor) => {
    finishMatch(opposite(loser), 'Timeout', `${loser === 'w' ? 'White' : 'Black'} ran out of time`);
  };

  const handleSquareClick = (sq: number) => {
    if (!isGameActive || gameOver || thinking) return;
    if (gameState.turn !== playerColor) return;

    const piece = gameState.board[sq];

    // Attempt to make move if already selected
    if (selectedSquare !== null) {
      const targetMove = activeLegals.find((m) => m.to === sq);
      if (targetMove) {
        if (targetMove.promotion) {
          setPendingPromotionMove(targetMove);
          return;
        }
        executeMove(targetMove);
        return;
      }
    }

    // Select piece
    if (piece && piece[0] === gameState.turn) {
      setSelectedSquare(sq);
      setActiveLegals(legalMoves(gameState, sq));
    } else {
      setSelectedSquare(null);
      setActiveLegals([]);
    }
  };

  const handlePromotionChoice = (promo: PieceType) => {
    if (!pendingPromotionMove) return;
    const m = { ...pendingPromotionMove, promote: promo };
    setPendingPromotionMove(null);
    executeMove(m);
  };

  const executeMove = (move: ChessMove) => {
    const mover = gameState.turn;
    const promo = move.promote || 'q';
    const beforeState = cloneState(gameState);

    // Evaluate move quality
    const moveQuality = evaluatePlayedMove(beforeState, move, mover);
    const san = sanFor(beforeState, move);

    const nextState = applyMove(gameState, move, promo);
    const key = positionKey(nextState);
    const updatedCount = (positionCounts[key] || 0) + 1;
    setPositionCounts((prev) => ({ ...prev, [key]: updatedCount }));

    if (move.capture || move.enPassant) {
      sounds.playCapture();
    } else {
      sounds.playMove();
    }

    if (inCheck(nextState, nextState.turn)) {
      sounds.playCheck();
    }

    setGameState(nextState);
    setLastMove({ from: move.from, to: move.to });
    setSelectedSquare(null);
    setActiveLegals([]);
    setHintMove(null);

    const newEntry: MoveLogEntry = {
      mover,
      notation: san,
      from: move.from,
      to: move.to,
      cls: moveQuality.cls,
      boardSnapshot: nextState.board.slice()
    };
    const updatedMoveLog = [...moveLog, newEntry];
    setMoveLog(updatedMoveLog);

    // Check terminal
    const end = terminalState(nextState, updatedCount);
    if (end.over) {
      finishMatch(end.winner || null, end.reason || 'Game Over', end.result || '', updatedMoveLog);
      return;
    }

    // If next turn is bot, trigger engine
    if (nextState.turn !== playerColor) {
      triggerBotMove(nextState, activeBot, updatedMoveLog);
    }
  };

  const triggerBotMove = (state: GameState, bot: BotPersonality, currentLog = moveLog) => {
    setThinking(true);
    setTimeout(() => {
      const engineRes = chooseEngineMove(state, bot.aiDepth, bot.blunderRate);
      setThinking(false);

      if (!engineRes) {
        const end = terminalState(state);
        finishMatch(end.winner || null, end.reason || 'Game Over', end.result || '', currentLog);
        return;
      }

      const botMove = engineRes.move;
      const botMover = state.turn;
      const beforeState = cloneState(state);
      const moveQuality = evaluatePlayedMove(beforeState, botMove, botMover);
      const san = sanFor(beforeState, botMove);

      const afterState = applyMove(state, botMove, botMove.promote || 'q');
      const key = positionKey(afterState);
      const updatedCount = (positionCounts[key] || 0) + 1;
      setPositionCounts((prev) => ({ ...prev, [key]: updatedCount }));

      if (botMove.capture || botMove.enPassant) {
        sounds.playCapture();
      } else {
        sounds.playMove();
      }

      if (inCheck(afterState, afterState.turn)) {
        sounds.playCheck();
      }

      setGameState(afterState);
      setLastMove({ from: botMove.from, to: botMove.to });

      const newEntry: MoveLogEntry = {
        mover: botMover,
        notation: san,
        from: botMove.from,
        to: botMove.to,
        cls: moveQuality.cls,
        boardSnapshot: afterState.board.slice()
      };
      const updatedLog = [...currentLog, newEntry];
      setMoveLog(updatedLog);

      const end = terminalState(afterState, updatedCount);
      if (end.over) {
        finishMatch(end.winner || null, end.reason || 'Game Over', end.result || '', updatedLog);
      }
    }, 450);
  };

  const finishMatch = (
    winner: PieceColor | null,
    reason: string,
    result: string,
    finalMoveLog = moveLog
  ) => {
    setGameOver(true);
    setIsGameActive(false);

    let actualScore = 0.5;
    if (winner === playerColor) actualScore = 1;
    else if (winner === opposite(playerColor)) actualScore = 0;

    const eloDelta = calculateEloDelta(profile.rating, activeBot.rating, actualScore);
    const newRating = Math.max(100, profile.rating + eloDelta);
    const coinsDelta = winner === playerColor ? 50 : 15;

    if (winner === playerColor) {
      sounds.playVictory();
    } else {
      sounds.playPuzzleWrong();
    }

    onUpdateProfile({
      rating: newRating,
      coins: profile.coins + coinsDelta,
      rankedWins: winner === playerColor ? profile.rankedWins + 1 : profile.rankedWins,
      rankedLosses: winner === opposite(playerColor) ? profile.rankedLosses + 1 : profile.rankedLosses,
      rankedDraws: winner === null ? profile.rankedDraws + 1 : profile.rankedDraws
    });

    onOpenReviewModal({
      winner,
      reason,
      movesCount: finalMoveLog.length,
      playerMover: playerColor,
      moveLog: finalMoveLog,
      eloChange: eloDelta
    });
  };

  const handleResign = () => {
    if (gameOver) return;
    finishMatch(opposite(playerColor), 'Resignation', `${playerColor === 'w' ? 'White' : 'Black'} resigned`);
  };

  const handleOfferDraw = () => {
    if (gameOver) return;
    finishMatch(null, 'Draw agreed', 'Match agreed to a mutual draw');
  };

  const handleCoachHint = () => {
    if (gameOver || thinking || gameState.turn !== playerColor) return;
    const res = chooseEngineMove(gameState, 4, 0);
    if (res) {
      setHintMove(res.move);
      sounds.playCheck();
    }
  };

  // Evaluation score for eval bar
  const rawEval = evaluateBoard(gameState);
  const evalCentipawns = Math.max(-1500, Math.min(1500, rawEval));
  const evalWhitePct = 50 + (evalCentipawns / 1500) * 45;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Board & Clocks Column */}
      <div className="lg:col-span-7 flex flex-col items-center">
        {/* Top Player (Opponent Bot) Banner */}
        <div className="w-full max-w-[620px] mb-2.5 bg-[#141d27] border border-[#233346] rounded-xl px-4 py-2.5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{activeBot.avatar}</span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{activeBot.name}</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  {activeBot.rating} Elo
                </span>
              </div>
              <span className="text-[11px] text-slate-400 block truncate max-w-[200px]">
                {thinking ? 'Calculating response...' : activeBot.title}
              </span>
            </div>
          </div>

          {clockMode !== 'casual' && (
            <div
              className={`font-mono text-sm sm:text-base font-bold px-3 py-1 rounded-lg border ${
                gameState.turn !== playerColor
                  ? 'bg-amber-950/40 border-amber-500/50 text-amber-300'
                  : 'bg-[#0f1721] border-[#1d2a3a] text-slate-400'
              }`}
            >
              <Clock className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5" />
              {playerColor === 'w'
                ? `${Math.floor(blackTime / 60)}:${(blackTime % 60).toString().padStart(2, '0')}`
                : `${Math.floor(whiteTime / 60)}:${(whiteTime % 60).toString().padStart(2, '0')}`}
            </div>
          )}
        </div>

        {/* Evaluation Bar & Board wrapper */}
        <div className="flex items-stretch gap-2 w-full max-w-[620px]">
          {/* Vertical Position Evaluation Gauge */}
          <div className="w-2.5 sm:w-3 bg-slate-800 rounded-full overflow-hidden flex flex-col shrink-0 border border-slate-700 shadow-inner relative">
            <div
              className="w-full bg-slate-900 transition-all duration-300"
              style={{ height: `${100 - evalWhitePct}%` }}
            />
            <div
              className="w-full bg-slate-100 transition-all duration-300"
              style={{ height: `${evalWhitePct}%` }}
            />
          </div>

          <ChessBoard
            state={gameState}
            selectedSquare={selectedSquare}
            legalMoves={activeLegals}
            lastMove={lastMove}
            flipped={flipped}
            activePieceSetId={profile.equippedPieceSet}
            activeBoardThemeId={profile.equippedBoardTheme}
            onSquareClick={handleSquareClick}
            onPromoteChoice={handlePromotionChoice}
            pendingPromotionMove={pendingPromotionMove}
            hintMove={hintMove}
            disabled={gameOver || thinking}
          />
        </div>

        {/* Bottom Player (User) Banner */}
        <div className="w-full max-w-[620px] mt-2.5 bg-[#141d27] border border-[#233346] rounded-xl px-4 py-2.5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-sm">
              YOU
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{profile.name}</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-950/40 text-emerald-400 border border-emerald-700/50">
                  {profile.rating} Elo
                </span>
              </div>
              <span className="text-[11px] text-slate-400 block">
                {gameState.turn === playerColor ? 'Your turn to move' : 'Waiting for opponent'}
              </span>
            </div>
          </div>

          {clockMode !== 'casual' && (
            <div
              className={`font-mono text-sm sm:text-base font-bold px-3 py-1 rounded-lg border ${
                gameState.turn === playerColor
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : 'bg-[#0f1721] border-[#1d2a3a] text-slate-400'
              }`}
            >
              <Clock className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5" />
              {playerColor === 'w'
                ? `${Math.floor(whiteTime / 60)}:${(whiteTime % 60).toString().padStart(2, '0')}`
                : `${Math.floor(blackTime / 60)}:${(blackTime % 60).toString().padStart(2, '0')}`}
            </div>
          )}
        </div>

        {/* Board Controls */}
        <div className="w-full max-w-[620px] grid grid-cols-4 gap-2 mt-3">
          <button
            type="button"
            onClick={() => setFlipped(!flipped)}
            className="py-2.5 px-3 rounded-xl bg-[#141d27] hover:bg-[#1d2a3a] border border-[#223347] text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            Flip
          </button>
          <button
            type="button"
            onClick={handleCoachHint}
            disabled={gameOver || thinking || gameState.turn !== playerColor}
            className="py-2.5 px-3 rounded-xl bg-cyan-950/30 hover:bg-cyan-900/40 border border-cyan-700/40 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors disabled:opacity-40"
          >
            <Lightbulb className="w-3.5 h-3.5" />
            Suggest
          </button>
          <button
            type="button"
            onClick={handleOfferDraw}
            disabled={gameOver || thinking}
            className="py-2.5 px-3 rounded-xl bg-[#141d27] hover:bg-[#1d2a3a] border border-[#223347] text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors disabled:opacity-40"
          >
            <Handshake className="w-3.5 h-3.5" />
            Draw
          </button>
          <button
            type="button"
            onClick={handleResign}
            disabled={gameOver || thinking}
            className="py-2.5 px-3 rounded-xl bg-rose-950/30 hover:bg-rose-900/40 border border-rose-700/40 text-rose-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors disabled:opacity-40"
          >
            <Flag className="w-3.5 h-3.5" />
            Resign
          </button>
        </div>
      </div>

      {/* Opponent Selector & Move Notation Column */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Opponent Selection Card */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
              Ranked Opponent
            </span>
            <div className="flex items-center gap-1">
              {(['casual', 'blitz', 'rapid'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => {
                    setClockMode(mode);
                    startNewMatch(activeBot, playerColor, mode);
                  }}
                  className={`text-[10px] font-bold uppercase px-2 py-1 rounded transition-colors cursor-pointer ${
                    clockMode === mode
                      ? 'bg-emerald-600 text-slate-950'
                      : 'bg-[#101720] text-slate-400 hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-4">
            {BOT_PERSONALITIES.slice(0, 6).map((bot) => (
              <button
                key={bot.id}
                type="button"
                onClick={() => {
                  setSelectedBotId(bot.id);
                  startNewMatch(bot);
                }}
                className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  selectedBotId === bot.id
                    ? 'bg-emerald-950/40 border-emerald-500 shadow-md scale-105'
                    : 'bg-[#101720] border-[#1d2b3b] hover:bg-[#182330]'
                }`}
              >
                <span className="text-xl">{bot.avatar}</span>
                <span className="text-[10px] font-bold text-white truncate max-w-[50px]">
                  {bot.name.split(' ')[0]}
                </span>
                <span className="text-[9px] font-mono font-semibold text-slate-400">
                  {bot.rating}
                </span>
              </button>
            ))}
          </div>

          <div className="bg-[#101720] border border-[#1d2b3b] rounded-xl p-3 text-xs text-slate-300">
            <p className="italic text-slate-300 mb-1">"{activeBot.quote}"</p>
            <span className="text-[11px] text-slate-400 block">
              Style: {activeBot.playstyle}
            </span>
          </div>
        </div>

        {/* Move History Notation Card */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl flex flex-col h-[380px]">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-[#213042]">
            <span className="text-xs uppercase font-bold tracking-wider text-slate-400">
              Move History
            </span>
            <span className="text-xs font-mono text-slate-400 font-semibold">
              {Math.ceil(moveLog.length / 2)} moves
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1 pr-1 font-mono text-xs">
            {moveLog.length === 0 ? (
              <div className="text-slate-500 text-xs italic text-center py-10">
                Moves will appear here as pieces are played.
              </div>
            ) : (
              Array.from({ length: Math.ceil(moveLog.length / 2) }).map((_, i) => {
                const whiteMove = moveLog[i * 2];
                const blackMove = moveLog[i * 2 + 1];

                const getBadge = (cls?: string) => {
                  if (cls === 'brilliant') return 'text-cyan-400 font-bold';
                  if (cls === 'inaccuracy') return 'text-yellow-400';
                  if (cls === 'mistake') return 'text-orange-400';
                  if (cls === 'blunder') return 'text-rose-400 font-bold';
                  return 'text-slate-200';
                };

                return (
                  <div
                    key={i}
                    className="grid grid-cols-12 py-1 px-2 rounded hover:bg-white/5 transition-colors"
                  >
                    <span className="col-span-2 text-slate-500 font-sans">{i + 1}.</span>
                    <span className={`col-span-5 font-bold ${getBadge(whiteMove?.cls)}`}>
                      {whiteMove?.notation || ''}
                    </span>
                    <span className={`col-span-5 font-bold ${getBadge(blackMove?.cls)}`}>
                      {blackMove?.notation || ''}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* New Game Button */}
          <div className="pt-3 border-t border-[#1f2e40]">
            <button
              type="button"
              onClick={() => startNewMatch()}
              className="w-full py-2.5 rounded-xl bg-[#1c2938] hover:bg-[#25364a] text-slate-200 border border-[#2d4157] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset / Rematch
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
