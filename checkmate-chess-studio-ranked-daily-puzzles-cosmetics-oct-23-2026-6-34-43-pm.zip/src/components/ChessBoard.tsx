import React, { useState } from 'react';
import {
  ChessMove,
  GameState,
  PieceCode,
  PieceColor,
  PieceType
} from '../types/chess';
import {
  colorOf,
  coord,
  FILES,
  idx,
  inCheck,
  kingSquare,
  typeOf
} from '../utils/chessEngine';
import { BOARD_THEMES, PIECE_SETS } from '../data/cosmetics';

interface ChessBoardProps {
  state: GameState;
  selectedSquare: number | null;
  legalMoves: ChessMove[];
  lastMove: { from: number; to: number } | null;
  flipped: boolean;
  activePieceSetId: string;
  activeBoardThemeId: string;
  onSquareClick: (index: number) => void;
  onPromoteChoice?: (promo: PieceType) => void;
  pendingPromotionMove?: ChessMove | null;
  hintMove?: ChessMove | null;
  disabled?: boolean;
}

export const ChessBoard: React.FC<ChessBoardProps> = ({
  state,
  selectedSquare,
  legalMoves,
  lastMove,
  flipped,
  activePieceSetId,
  activeBoardThemeId,
  onSquareClick,
  onPromoteChoice,
  pendingPromotionMove,
  hintMove,
  disabled
}) => {
  const currentTheme =
    BOARD_THEMES.find((t) => t.id === activeBoardThemeId) || BOARD_THEMES[0];
  const currentPieceSet =
    PIECE_SETS.find((p) => p.id === activePieceSetId) || PIECE_SETS[0];

  const [hoveredSquare, setHoveredSquare] = useState<number | null>(null);

  // Check state
  const checked = inCheck(state, state.turn);
  const checkedKingSq = checked ? kingSquare(state, state.turn) : -1;

  // Map of destination square -> legal move object
  const legalTargets = new Map<number, ChessMove>();
  legalMoves.forEach((m) => {
    legalTargets.set(m.to, m);
  });

  const getPieceGlyph = (code: PieceCode) => {
    const c = colorOf(code)!;
    const t = typeOf(code)!;
    return currentPieceSet.glyphs[c]?.[t] || code;
  };

  return (
    <div className="relative select-none touch-manipulation w-full max-w-[620px] aspect-square rounded-2xl p-2 sm:p-3 bg-[#131b24] border border-[#223142] shadow-2xl shadow-black/60">
      {/* Board Grid */}
      <div
        className="w-full h-full grid grid-cols-8 grid-rows-8 rounded-xl overflow-hidden shadow-inner relative"
        style={
          {
            backgroundColor: currentTheme.dark
          } as React.CSSProperties
        }
      >
        {Array.from({ length: 64 }).map((_, visualIdx) => {
          const file = flipped ? 7 - (visualIdx % 8) : visualIdx % 8;
          const rank = flipped ? Math.floor(visualIdx / 8) : 7 - Math.floor(visualIdx / 8);
          const sqIdx = idx(file, rank);
          const isLight = (file + rank) % 2 === 0;

          const piece = state.board[sqIdx];
          const isSelected = selectedSquare === sqIdx;
          const isLastMove = lastMove && (lastMove.from === sqIdx || lastMove.to === sqIdx);
          const isCheckedKing = checkedKingSq === sqIdx;
          const isLegalTarget = legalTargets.has(sqIdx);
          const isHintSquare = hintMove && (hintMove.from === sqIdx || hintMove.to === sqIdx);
          const targetMove = legalTargets.get(sqIdx);

          const squareBg = isLight ? currentTheme.light : currentTheme.dark;

          return (
            <button
              key={sqIdx}
              type="button"
              disabled={disabled}
              onClick={() => onSquareClick(sqIdx)}
              onMouseEnter={() => setHoveredSquare(sqIdx)}
              onMouseLeave={() => setHoveredSquare(null)}
              aria-label={`${coord(sqIdx)} ${piece || 'empty'}`}
              className="relative aspect-square flex items-center justify-center p-0 m-0 border-0 outline-none transition-colors duration-100 cursor-pointer focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:z-10 group"
              style={{
                backgroundColor: isSelected
                  ? currentTheme.sel
                  : squareBg
              }}
            >
              {/* Last move overlay */}
              {isLastMove && !isSelected && (
                <div className="absolute inset-0 bg-yellow-400/25 pointer-events-none" />
              )}

              {/* Check warning alert overlay on King */}
              {isCheckedKing && (
                <div className="absolute inset-0 bg-gradient-to-tr from-red-600/70 to-rose-500/80 animate-pulse pointer-events-none rounded-none" />
              )}

              {/* Coach Hint square highlight */}
              {isHintSquare && !isSelected && (
                <div className="absolute inset-0 bg-cyan-400/30 ring-2 ring-cyan-400 ring-inset pointer-events-none animate-pulse" />
              )}

              {/* Hover tint */}
              {hoveredSquare === sqIdx && !isSelected && (
                <div className="absolute inset-0 bg-white/10 pointer-events-none" />
              )}

              {/* Legal move indicator */}
              {isLegalTarget && (
                <>
                  {targetMove?.capture || targetMove?.enPassant ? (
                    <div
                      className="absolute inset-1 sm:inset-1.5 rounded-full border-4 sm:border-[5px] pointer-events-none transition-transform group-hover:scale-105"
                      style={{ borderColor: currentTheme.legal, opacity: 0.75 }}
                    />
                  ) : (
                    <div
                      className="absolute w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full pointer-events-none shadow-sm transition-transform group-hover:scale-125"
                      style={{ backgroundColor: currentTheme.legal, opacity: 0.8 }}
                    />
                  )}
                </>
              )}

              {/* Piece Glyph */}
              {piece && (
                <span
                  className={`relative z-10 leading-none select-none transition-transform duration-150 ease-out group-hover:scale-110 active:scale-95 text-[clamp(28px,6vw,56px)] ${
                    colorOf(piece) === 'w'
                      ? 'text-[#fbf9f4] drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]'
                      : 'text-[#18181b] drop-shadow-[0_1px_2px_rgba(255,255,255,0.4)]'
                  } ${currentPieceSet.styleClass || ''}`}
                >
                  {getPieceGlyph(piece)}
                </span>
              )}

              {/* Coordinate Labels: Rank on left/right edge, File on bottom edge */}
              {((!flipped && file === 0) || (flipped && file === 7)) && (
                <span
                  className={`absolute top-0.5 left-1 text-[9px] sm:text-[10px] font-bold pointer-events-none opacity-60 select-none ${
                    isLight ? 'text-black/60' : 'text-white/60'
                  }`}
                >
                  {rank + 1}
                </span>
              )}
              {((!flipped && rank === 0) || (flipped && rank === 7)) && (
                <span
                  className={`absolute bottom-0.5 right-1 text-[9px] sm:text-[10px] font-bold pointer-events-none opacity-60 select-none ${
                    isLight ? 'text-black/60' : 'text-white/60'
                  }`}
                >
                  {FILES[file]}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Promotion Choice Popover */}
      {pendingPromotionMove && onPromoteChoice && (
        <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 rounded-2xl p-4">
          <div className="bg-[#182330] border border-[#2b3d52] rounded-2xl p-5 shadow-2xl text-center max-w-xs w-full animate-in fade-in zoom-in-95 duration-150">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-400 mb-1 block">
              Pawn Promotion
            </span>
            <h4 className="text-base font-bold text-white mb-3">Choose Your Piece</h4>
            <div className="grid grid-cols-4 gap-2">
              {(['q', 'r', 'b', 'n'] as const).map((promoType) => {
                const moverColor = state.turn;
                const glyph =
                  currentPieceSet.glyphs[moverColor]?.[promoType] || promoType;
                const label: Record<'q' | 'r' | 'b' | 'n', string> = {
                  q: 'Queen',
                  r: 'Rook',
                  b: 'Bishop',
                  n: 'Knight'
                };

                return (
                  <button
                    key={promoType}
                    type="button"
                    onClick={() => onPromoteChoice(promoType)}
                    className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-[#202d3d] hover:bg-emerald-600/30 border border-[#2f4258] hover:border-emerald-500/60 transition-all cursor-pointer group"
                  >
                    <span className="text-3xl sm:text-4xl leading-none text-white group-hover:scale-110 transition-transform">
                      {glyph}
                    </span>
                    <span className="text-[10px] font-medium text-slate-300 mt-1">
                      {label[promoType]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
