import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { ChessBoard } from './ChessBoard';
import { Puzzle, PlayerProfile, ChessMove, PieceType } from '../types/chess';
import { CHESS_PUZZLES } from '../data/puzzles';
import {
  applyMove,
  cloneState,
  coord,
  legalMoves,
  parseCoord,
  parseFEN,
  sanFor
} from '../utils/chessEngine';
import { sounds } from '../utils/soundEffects';
import { Flame, Lightbulb, CheckCircle2, RotateCcw, Award, ChevronLeft, ChevronRight } from 'lucide-react';

interface DailyPuzzleViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
}

export const DailyPuzzleView: React.FC<DailyPuzzleViewProps> = ({
  profile,
  onUpdateProfile
}) => {
  // Sort puzzles with daily puzzles first
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const currentPuzzle = CHESS_PUZZLES[puzzleIndex] || CHESS_PUZZLES[0];

  const [gameState, setGameState] = useState(() => parseFEN(currentPuzzle.fen));
  const [selectedSquare, setSelectedSquare] = useState<number | null>(null);
  const [activeLegals, setActiveLegals] = useState<ChessMove[]>([]);
  const [lastMove, setLastMove] = useState<{ from: number; to: number } | null>(null);
  const [moveStep, setMoveStep] = useState(0); // Index in solutionUci
  const [status, setStatus] = useState<'playing' | 'wrong' | 'solved'>('playing');
  const [feedbackMsg, setFeedbackMsg] = useState<string>('');
  const [hintActive, setHintActive] = useState(false);
  const [pendingPromotionMove, setPendingPromotionMove] = useState<ChessMove | null>(null);

  // Initialize or reset when puzzle changes
  useEffect(() => {
    resetPuzzle();
  }, [currentPuzzle]);

  const resetPuzzle = () => {
    const initial = parseFEN(currentPuzzle.fen);
    setGameState(initial);
    setSelectedSquare(null);
    setActiveLegals([]);
    setLastMove(null);
    setMoveStep(0);
    setStatus('playing');
    setFeedbackMsg(`${currentPuzzle.playerColor === 'w' ? 'White' : 'Black'} to move and find the winning tactic.`);
    setHintActive(false);
    setPendingPromotionMove(null);
  };

  const handleSquareClick = (sq: number) => {
    if (status === 'solved') return;

    const piece = gameState.board[sq];

    // If a square is already selected, try to make a move
    if (selectedSquare !== null) {
      const targetMove = activeLegals.find((m) => m.to === sq);
      if (targetMove) {
        if (targetMove.promotion) {
          setPendingPromotionMove(targetMove);
          return;
        }
        executePlayerMove(targetMove);
        return;
      }
    }

    // Select piece if it's the current player's piece
    if (piece && piece[0] === gameState.turn) {
      setSelectedSquare(sq);
      setActiveLegals(legalMoves(gameState, sq));
    } else {
      setSelectedSquare(null);
      setActiveLegals([]);
    }
  };

  const handlePromotionChoice = (promo: PieceType) => {
    if (!pendingPromotionMove) return;
    const moveWithPromo = { ...pendingPromotionMove, promote: promo };
    setPendingPromotionMove(null);
    executePlayerMove(moveWithPromo);
  };

  const executePlayerMove = (move: ChessMove) => {
    const expectedUci = currentPuzzle.solutionUci[moveStep];
    const fromCoord = coord(move.from);
    const toCoord = coord(move.to);
    const playedUci = `${fromCoord}${toCoord}${move.promote || ''}`;

    // Validate against solution
    const isCorrect =
      playedUci.slice(0, 4) === expectedUci.slice(0, 4);

    if (!isCorrect) {
      // Wrong move feedback
      sounds.playPuzzleWrong();
      setStatus('wrong');
      setFeedbackMsg("That's not the best continuation! Take another look at the position.");
      setSelectedSquare(null);
      setActiveLegals([]);
      return;
    }

    // Correct move!
    sounds.playMove();
    const nextState = applyMove(gameState, move, move.promote || 'q');
    setGameState(nextState);
    setLastMove({ from: move.from, to: move.to });
    setSelectedSquare(null);
    setActiveLegals([]);

    const nextStep = moveStep + 1;
    setMoveStep(nextStep);

    // Check if puzzle is finished
    if (nextStep >= currentPuzzle.solutionUci.length) {
      handlePuzzleSolved();
      return;
    }

    // Otherwise, play opponent automated response from solution
    setStatus('playing');
    setFeedbackMsg("Excellent move! Keep going...");
    setTimeout(() => {
      const oppUci = currentPuzzle.solutionUci[nextStep];
      if (!oppUci) {
        handlePuzzleSolved();
        return;
      }
      const oppFrom = parseCoord(oppUci.slice(0, 2));
      const oppTo = parseCoord(oppUci.slice(2, 4));
      const oppPromo = (oppUci[4] as PieceType) || 'q';

      const oppMove: ChessMove = {
        from: oppFrom,
        to: oppTo,
        promotion: oppUci.length === 5,
        promote: oppPromo
      };

      sounds.playCapture();
      const afterOpp = applyMove(nextState, oppMove, oppPromo);
      setGameState(afterOpp);
      setLastMove({ from: oppFrom, to: oppTo });
      setMoveStep(nextStep + 1);

      if (nextStep + 1 >= currentPuzzle.solutionUci.length) {
        handlePuzzleSolved();
      } else {
        setFeedbackMsg("Find the next move to finish the tactic!");
      }
    }, 600);
  };

  const handlePuzzleSolved = () => {
    sounds.playSuccess();
    setStatus('solved');
    setFeedbackMsg(`Puzzle solved! ${currentPuzzle.explanation}`);

    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // fail safe
    }

    // Reward player: bonus rating + coins + streak
    const coinsReward = 25;
    const ratingReward = 15;
    const isToday = currentPuzzle.dateKey === new Date().toISOString().slice(0, 10);
    const newStreak = isToday ? profile.puzzleStreak + 1 : profile.puzzleStreak;

    onUpdateProfile({
      coins: profile.coins + coinsReward,
      rating: profile.rating + ratingReward,
      puzzlesSolvedCount: profile.puzzlesSolvedCount + 1,
      puzzleStreak: newStreak,
      lastDailySolvedDate: isToday ? currentPuzzle.dateKey : profile.lastDailySolvedDate
    });
  };

  const getHint = () => {
    setHintActive(true);
    const expected = currentPuzzle.solutionUci[moveStep];
    if (expected) {
      const fromSq = parseCoord(expected.slice(0, 2));
      const toSq = parseCoord(expected.slice(2, 4));
      setSelectedSquare(fromSq);
      setActiveLegals(legalMoves(gameState, fromSq));
      setFeedbackMsg(`Hint: Focus on the piece at ${expected.slice(0, 2).toUpperCase()} moving towards ${expected.slice(2, 4).toUpperCase()}!`);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left/Main Column: Chessboard */}
      <div className="lg:col-span-7 flex flex-col items-center">
        <ChessBoard
          state={gameState}
          selectedSquare={selectedSquare}
          legalMoves={activeLegals}
          lastMove={lastMove}
          flipped={currentPuzzle.playerColor === 'b'}
          activePieceSetId={profile.equippedPieceSet}
          activeBoardThemeId={profile.equippedBoardTheme}
          onSquareClick={handleSquareClick}
          onPromoteChoice={handlePromotionChoice}
          pendingPromotionMove={pendingPromotionMove}
          hintMove={
            hintActive && currentPuzzle.solutionUci[moveStep]
              ? {
                  from: parseCoord(currentPuzzle.solutionUci[moveStep].slice(0, 2)),
                  to: parseCoord(currentPuzzle.solutionUci[moveStep].slice(2, 4))
                }
              : null
          }
        />

        {/* Tactical Status Banner */}
        <div className="mt-4 w-full max-w-[620px] bg-[#141d27] border border-[#233346] rounded-xl p-4 shadow-lg flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                status === 'solved'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : status === 'wrong'
                  ? 'bg-rose-500/20 text-rose-400'
                  : 'bg-cyan-500/20 text-cyan-400'
              }`}
            >
              {status === 'solved' ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : (
                <Lightbulb className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block">
                {status === 'solved' ? 'Solved!' : status === 'wrong' ? 'Try Again' : 'Tactic Objective'}
              </span>
              <p className="text-sm font-medium text-slate-200 truncate">
                {feedbackMsg}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {status === 'wrong' && (
              <button
                type="button"
                onClick={resetPuzzle}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Retry
              </button>
            )}
            {status === 'playing' && (
              <button
                type="button"
                onClick={getHint}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Lightbulb className="w-3.5 h-3.5" />
                Hint
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Right Column: Puzzle Info, Daily Streak & Selector */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Streak & Reward Card */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#213042]">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Flame className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                  {profile.puzzleStreak} Day Streak
                </h3>
                <span className="text-xs text-slate-400">Daily Tactics Routine</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs uppercase font-semibold tracking-wider text-slate-400 block">
                Total Solved
              </span>
              <span className="text-lg font-black text-emerald-400">
                {profile.puzzlesSolvedCount}
              </span>
            </div>
          </div>

          <div className="bg-[#101720] border border-[#1d2b3b] rounded-xl p-3.5 flex items-center justify-between text-xs text-slate-300">
            <span>🎁 Reward upon completion:</span>
            <div className="flex items-center gap-3 font-semibold">
              <span className="text-yellow-400">+25 Coins</span>
              <span className="text-emerald-400">+15 Elo</span>
            </div>
          </div>
        </div>

        {/* Current Puzzle Card */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
              Tactical Puzzle #{puzzleIndex + 1}
            </span>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
              Rating {currentPuzzle.rating}
            </span>
          </div>

          <h2 className="text-xl font-black text-white mb-1.5">
            {currentPuzzle.title}
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-4">
            <span>Theme: {currentPuzzle.theme}</span>
            <span>·</span>
            <span>Level: {currentPuzzle.difficulty}</span>
          </div>

          <div className="bg-[#101720] border border-[#1c2938] rounded-xl p-3.5 mb-5 text-xs leading-relaxed text-slate-300">
            <strong className="text-white block mb-1">Coach Note:</strong>
            {currentPuzzle.explanation}
          </div>

          {/* Navigation Controls between puzzles */}
          <div className="flex items-center justify-between pt-2 border-t border-[#1f2d3d]">
            <button
              type="button"
              disabled={puzzleIndex === 0}
              onClick={() => setPuzzleIndex((prev) => Math.max(0, prev - 1))}
              className="px-3 py-2 text-xs font-semibold rounded-lg bg-[#1c2736] hover:bg-[#253549] text-slate-200 border border-[#2b3c50] disabled:opacity-30 disabled:pointer-events-none flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </button>

            <span className="text-xs font-bold text-slate-400">
              {puzzleIndex + 1} of {CHESS_PUZZLES.length}
            </span>

            <button
              type="button"
              disabled={puzzleIndex >= CHESS_PUZZLES.length - 1}
              onClick={() => setPuzzleIndex((prev) => Math.min(CHESS_PUZZLES.length - 1, prev + 1))}
              className="px-3 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 border border-transparent font-bold disabled:opacity-30 disabled:pointer-events-none flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              Next Puzzle
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Puzzle Archive List */}
        <div className="bg-[#141d27] border border-[#233346] rounded-2xl p-5 shadow-xl">
          <h4 className="text-xs uppercase font-bold tracking-wider text-slate-400 mb-3 flex items-center justify-between">
            <span>Tactics Library</span>
            <span className="text-[11px] font-normal text-slate-500">
              {CHESS_PUZZLES.length} Puzzles
            </span>
          </h4>

          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
            {CHESS_PUZZLES.map((p, idx) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPuzzleIndex(idx)}
                className={`w-full text-left p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  idx === puzzleIndex
                    ? 'bg-emerald-950/30 border-emerald-500/50 text-white'
                    : 'bg-[#101722] border-[#1d2b3b] text-slate-300 hover:bg-[#182332]'
                }`}
              >
                <div>
                  <div className="text-xs font-bold truncate max-w-[200px]">
                    {p.title}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {p.theme} · {p.difficulty}
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400">
                  ★ {p.rating}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
