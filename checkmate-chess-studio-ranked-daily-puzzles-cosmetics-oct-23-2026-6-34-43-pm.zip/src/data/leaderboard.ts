import { BotPersonality, LeaderboardPlayer, PlayerProfile, RankTier } from '../types/chess';

export interface TierInfo {
  tier: RankTier;
  minRating: number;
  maxRating: number;
  color: string;
  badgeBg: string;
  badgeBorder: string;
  icon: string;
}

export const TIER_CONFIG: Record<RankTier, TierInfo> = {
  Bronze: {
    tier: 'Bronze',
    minRating: 0,
    maxRating: 999,
    color: '#cd7f32',
    badgeBg: 'bg-amber-950/40 text-amber-400',
    badgeBorder: 'border-amber-700/50',
    icon: '🥉'
  },
  Silver: {
    tier: 'Silver',
    minRating: 1000,
    maxRating: 1299,
    color: '#c0c0c0',
    badgeBg: 'bg-slate-800 text-slate-200',
    badgeBorder: 'border-slate-500/50',
    icon: '🥈'
  },
  Gold: {
    tier: 'Gold',
    minRating: 1300,
    maxRating: 1599,
    color: '#ffd700',
    badgeBg: 'bg-yellow-950/40 text-yellow-300',
    badgeBorder: 'border-yellow-600/50',
    icon: '🥇'
  },
  Platinum: {
    tier: 'Platinum',
    minRating: 1600,
    maxRating: 1899,
    color: '#00ced1',
    badgeBg: 'bg-cyan-950/40 text-cyan-300',
    badgeBorder: 'border-cyan-500/50',
    icon: '💎'
  },
  Diamond: {
    tier: 'Diamond',
    minRating: 1900,
    maxRating: 2199,
    color: '#9370db',
    badgeBg: 'bg-purple-950/40 text-purple-300',
    badgeBorder: 'border-purple-500/50',
    icon: '🔮'
  },
  Master: {
    tier: 'Master',
    minRating: 2200,
    maxRating: 2399,
    color: '#f43f5e',
    badgeBg: 'bg-rose-950/40 text-rose-300',
    badgeBorder: 'border-rose-500/50',
    icon: '⚔️'
  },
  Grandmaster: {
    tier: 'Grandmaster',
    minRating: 2400,
    maxRating: 3000,
    color: '#e11d48',
    badgeBg: 'bg-gradient-to-r from-amber-500/20 to-red-500/20 text-amber-200',
    badgeBorder: 'border-amber-500/50',
    icon: '👑'
  }
};

export function getTierForRating(rating: number): RankTier {
  if (rating >= 2400) return 'Grandmaster';
  if (rating >= 2200) return 'Master';
  if (rating >= 1900) return 'Diamond';
  if (rating >= 1600) return 'Platinum';
  if (rating >= 1300) return 'Gold';
  if (rating >= 1000) return 'Silver';
  return 'Bronze';
}

export function calculateEloDelta(playerRating: number, opponentRating: number, actualScore: number, kFactor = 32): number {
  const expected = 1 / (1 + Math.pow(10, (opponentRating - playerRating) / 400));
  const delta = Math.round(kFactor * (actualScore - expected));
  return delta;
}

export const BOT_PERSONALITIES: BotPersonality[] = [
  {
    id: 'bot-pete',
    name: 'Peasant Pete',
    title: 'Casual Woodpusher',
    avatar: '👨‍🌾',
    tier: 'Bronze',
    rating: 750,
    aiDepth: 2,
    blunderRate: 0.35,
    playstyle: 'Aggressive pawn pusher who often neglects piece safety.',
    quote: "I move fast and break things! Wait, was that rook important?",
    unlockedByDefault: true
  },
  {
    id: 'bot-sammy',
    name: 'Sammy Squirrel',
    title: 'Tactical Scrambler',
    avatar: '🐿️',
    tier: 'Bronze',
    rating: 950,
    aiDepth: 2,
    blunderRate: 0.22,
    playstyle: 'Jumps pieces forward into tricky spots, but leaves weaknesses.',
    quote: "Nuts for tactical hops! Watch my knights jump around!",
    unlockedByDefault: true
  },
  {
    id: 'bot-leo',
    name: 'Knight-Errant Leo',
    title: 'Fork Enthusiast',
    avatar: '🤺',
    tier: 'Silver',
    rating: 1200,
    aiDepth: 3,
    blunderRate: 0.12,
    playstyle: 'Solid club player with a sharp eye for double attacks and forks.',
    quote: "A knight on the rim is dim, but in the center, it strikes like thunder.",
    unlockedByDefault: true
  },
  {
    id: 'bot-maya',
    name: 'Tactical Maya',
    title: 'Calculation Prodigy',
    avatar: '👩‍🔬',
    tier: 'Gold',
    rating: 1450,
    aiDepth: 3,
    blunderRate: 0.05,
    playstyle: 'Calculates multiple plies ahead and punishes undefended hanging pieces.',
    quote: "Tactics flow from a superior position. Every tempo matters.",
    unlockedByDefault: true
  },
  {
    id: 'bot-rook',
    name: 'Professor Rook',
    title: 'Positional Maestro',
    avatar: '🧙‍♂️',
    tier: 'Platinum',
    rating: 1750,
    aiDepth: 4,
    blunderRate: 0.02,
    playstyle: 'Seizes open files, controls the center, and grinds down endgames.',
    quote: "Patience. The pieces know when to strike.",
    unlockedByDefault: false
  },
  {
    id: 'bot-victor',
    name: 'Grandmaster Victor',
    title: 'International Master',
    avatar: '🤴',
    tier: 'Diamond',
    rating: 2050,
    aiDepth: 4,
    blunderRate: 0.005,
    playstyle: 'Deep tactical vision with ruthless conversion of small positional advantages.',
    quote: "Chess is 99% calculation and 1% psychological warfare.",
    unlockedByDefault: false
  },
  {
    id: 'bot-zenith',
    name: 'Deep Zenith',
    title: 'Grandmaster Engine',
    avatar: '🤖',
    tier: 'Grandmaster',
    rating: 2450,
    aiDepth: 5,
    blunderRate: 0.0,
    playstyle: 'Relentless deep alpha-beta search. Zero material or tactical oversights.',
    quote: "Processing 2,400,000 nodes per second. Checkmate is inevitable.",
    unlockedByDefault: false
  }
];

export const INITIAL_LEADERBOARD: LeaderboardPlayer[] = [
  { id: 'p1', name: 'Deep Zenith', avatar: '🤖', rating: 2450, tier: 'Grandmaster', wins: 412, losses: 18, draws: 45, streak: 12, botId: 'bot-zenith' },
  { id: 'p2', name: 'MagnusVibe', avatar: '👑', rating: 2380, tier: 'Master', wins: 340, losses: 55, draws: 62, streak: 7 },
  { id: 'p3', name: 'HikaruBlitz', avatar: '⚡', rating: 2310, tier: 'Master', wins: 388, losses: 82, draws: 40, streak: 5 },
  { id: 'p4', name: 'Grandmaster Victor', avatar: '🤴', rating: 2050, tier: 'Diamond', wins: 290, losses: 95, draws: 38, streak: 3, botId: 'bot-victor' },
  { id: 'p5', name: 'QueenOfGambits', avatar: '💃', rating: 1940, tier: 'Diamond', wins: 210, losses: 104, draws: 29, streak: 4 },
  { id: 'p6', name: 'Professor Rook', avatar: '🧙‍♂️', rating: 1750, tier: 'Platinum', wins: 184, losses: 112, draws: 31, streak: 2, botId: 'bot-rook' },
  { id: 'p7', name: 'Tactical Maya', avatar: '👩‍🔬', rating: 1450, tier: 'Gold', wins: 142, losses: 108, draws: 20, streak: 1, botId: 'bot-maya' },
  { id: 'p8', name: 'Knight-Errant Leo', avatar: '🤺', rating: 1200, tier: 'Silver', wins: 98, losses: 115, draws: 16, streak: 0, botId: 'bot-leo' },
  { id: 'p9', name: 'Sammy Squirrel', avatar: '🐿️', rating: 950, tier: 'Bronze', wins: 64, losses: 140, draws: 12, streak: 0, botId: 'bot-sammy' },
  { id: 'p10', name: 'Peasant Pete', avatar: '👨‍🌾', rating: 750, tier: 'Bronze', wins: 38, losses: 180, draws: 9, streak: 0, botId: 'bot-pete' }
];

const STORAGE_KEY = 'checkmate_player_profile_v2';

export function loadPlayerProfile(): PlayerProfile {
  if (typeof window === 'undefined') {
    return defaultProfile();
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...defaultProfile(), ...parsed };
    }
  } catch {
    // fallback
  }
  return defaultProfile();
}

export function savePlayerProfile(profile: PlayerProfile): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch {
    // fallback
  }
}

function defaultProfile(): PlayerProfile {
  return {
    name: 'Chess Challenger',
    rating: 1200,
    coins: 200,
    puzzleStreak: 1,
    lastDailySolvedDate: null,
    puzzlesSolvedCount: 3,
    rankedWins: 5,
    rankedLosses: 3,
    rankedDraws: 1,
    equippedPieceSet: 'staunton',
    equippedBoardTheme: 'emerald',
    unlockedPieceSets: ['staunton'],
    unlockedBoardThemes: ['emerald', 'walnut'],
    puzzleRushHighScore: 4
  };
}
