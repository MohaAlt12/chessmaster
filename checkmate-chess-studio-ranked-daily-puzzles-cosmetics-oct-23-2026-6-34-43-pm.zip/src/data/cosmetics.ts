import { PieceSetOption, BoardThemeOption } from '../types/chess';

export const PIECE_SETS: PieceSetOption[] = [
  {
    id: 'staunton',
    name: 'Staunton Royal',
    description: 'The timeless standard tournament silhouette with crisp serif outlines.',
    price: 0,
    previewGlyphs: { w: '♔', b: '♚' },
    glyphs: {
      w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
      b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' }
    },
    styleClass: 'font-serif'
  },
  {
    id: 'neo-bauhaus',
    name: 'Neo Bauhaus',
    description: 'Clean Scandinavian modernist geometric symbols with bold silhouettes.',
    price: 150,
    previewGlyphs: { w: '♚', b: '♚' },
    glyphs: {
      w: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' },
      b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' }
    },
    styleClass: 'font-sans font-black'
  },
  {
    id: 'celestial',
    name: 'Celestial Cosmos',
    description: 'Cosmic astral bodies: Sun King, Galaxy Queen, Comet Knight and Star Pawns.',
    price: 350,
    previewGlyphs: { w: '☀️', b: '🌑' },
    glyphs: {
      w: { k: '☀️', q: '✨', r: '🏰', b: '🔮', n: '💫', p: '⭐️' },
      b: { k: '🌑', q: '🌌', r: '🛸', b: '🪐', n: '☄️', p: '✦' }
    },
    styleClass: 'text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]'
  },
  {
    id: 'cyber-neon',
    name: 'Cyberpunk Neon',
    description: 'Futuristic electric styling with vibrant high-contrast glowing neon runes.',
    price: 500,
    previewGlyphs: { w: '⚡', b: '☣' },
    glyphs: {
      w: { k: '⚡', q: '◈', r: '⌸', b: '▲', n: '♞', p: '•' },
      b: { k: '☣', q: '◆', r: '⌺', b: '▼', n: '♞', p: '∘' }
    },
    styleClass: 'font-mono text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.7)]'
  },
  {
    id: 'gothic',
    name: 'Gothic Woodcarver',
    description: 'Ornate medieval heraldic carvings reminiscent of ancient European chess sets.',
    price: 750,
    previewGlyphs: { w: '♔', b: '♛' },
    glyphs: {
      w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
      b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' }
    },
    styleClass: 'font-medieval italic drop-shadow-[0_4px_6px_rgba(0,0,0,0.6)]'
  },
  {
    id: 'letters',
    name: 'Grandmaster Initials',
    description: 'Minimalist algebraic shorthand letters preferred by rapid blindfold masters.',
    price: 100,
    previewGlyphs: { w: 'K', b: 'k' },
    glyphs: {
      w: { k: 'K', q: 'Q', r: 'R', b: 'B', n: 'N', p: 'P' },
      b: { k: 'k', q: 'q', r: 'r', b: 'b', n: 'n', p: 'p' }
    },
    styleClass: 'font-mono font-bold tracking-tight'
  }
];

export const BOARD_THEMES: BoardThemeOption[] = [
  {
    id: 'emerald',
    name: 'Tournament Emerald',
    description: 'The timeless FIDE World Championship green & buff felt tone.',
    price: 0,
    light: '#eaefe3',
    dark: '#568b55',
    sel: '#f7f768',
    legal: '#417540',
    accent: '#3ab87e',
    previewClass: 'from-[#eaefe3] to-[#568b55]'
  },
  {
    id: 'walnut',
    name: 'Classic Walnut',
    description: 'Handcrafted natural birch & deep polished walnut woodgrain.',
    price: 0,
    light: '#eedbc0',
    dark: '#9b673c',
    sel: '#ffe066',
    legal: '#7a4f2b',
    accent: '#d97706',
    previewClass: 'from-[#eedbc0] to-[#9b673c]'
  },
  {
    id: 'midnight',
    name: 'Midnight Obsidian',
    description: 'Stealth matte dark titanium and deep carbon for reduced eye fatigue.',
    price: 200,
    light: '#323c4a',
    dark: '#1a202c',
    sel: '#fbbf24',
    legal: '#38bdf8',
    accent: '#38bdf8',
    previewClass: 'from-[#323c4a] to-[#1a202c]'
  },
  {
    id: 'ocean',
    name: 'Deep Marine',
    description: 'Soothing nautical seafoam and deep ocean blue.',
    price: 250,
    light: '#dbebf5',
    dark: '#3f6a8a',
    sel: '#fef08a',
    legal: '#0ea5e9',
    accent: '#0284c7',
    previewClass: 'from-[#dbebf5] to-[#3f6a8a]'
  },
  {
    id: 'rosewood',
    name: 'Rosewood Blush',
    description: 'Warm berry rose and alabaster stone for an elegant flair.',
    price: 300,
    light: '#f7e8ec',
    dark: '#a84c66',
    sel: '#fde047',
    legal: '#db2777',
    accent: '#f43f5e',
    previewClass: 'from-[#f7e8ec] to-[#a84c66]'
  },
  {
    id: 'cyberpunk',
    name: 'Cyber Grid 2077',
    description: 'High-tech neon cyan and dark abyss grid with pulsing highlights.',
    price: 450,
    light: '#1e3347',
    dark: '#0e1a26',
    sel: '#06b6d4',
    legal: '#22d3ee',
    accent: '#06b6d4',
    previewClass: 'from-[#1e3347] to-[#0e1a26]'
  },
  {
    id: 'desert',
    name: 'Saharan Gold',
    description: 'Golden dunes and sun-bleached desert limestone.',
    price: 350,
    light: '#f8f2e2',
    dark: '#c49e5d',
    sel: '#fef08a',
    legal: '#b45309',
    accent: '#f59e0b',
    previewClass: 'from-[#f8f2e2] to-[#c49e5d]'
  }
];
