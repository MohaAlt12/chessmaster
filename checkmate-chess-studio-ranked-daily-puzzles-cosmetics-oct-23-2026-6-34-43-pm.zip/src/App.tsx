/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  GameState,
  PieceColor,
  MoveLogEntry,
  PlayerProfile
} from './types/chess';
import { loadPlayerProfile, savePlayerProfile } from './data/leaderboard';
import { sounds } from './utils/soundEffects';
import { RankedMatchView } from './components/RankedMatchView';
import { DailyPuzzleView } from './components/DailyPuzzleView';
import { PuzzleRushView } from './components/PuzzleRushView';
import { LeaderboardView } from './components/LeaderboardView';
import { CosmeticsShop } from './components/CosmeticsShop';
import { BoardEditorView } from './components/BoardEditorView';
import { GameReviewModal } from './components/GameReviewModal';
import {
  Swords,
  Puzzle,
  Zap,
  Trophy,
  Sparkles,
  Edit3,
  Volume2,
  VolumeX,
  Coins,
  Flame
} from 'lucide-react';

export default function App() {
  const [profile, setProfile] = useState<PlayerProfile>(() => loadPlayerProfile());
  const [activeTab, setActiveTab] = useState<
    'ranked' | 'daily' | 'rush' | 'leaderboard' | 'cosmetics' | 'editor'
  >('ranked');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Selected bot to challenge from leaderboard
  const [targetChallengeBotId, setTargetChallengeBotId] = useState<string | undefined>(undefined);

  // Custom position state when launched from Board Editor
  const [customGameState, setCustomGameState] = useState<GameState | null>(null);

  // Post match review modal state
  const [reviewData, setReviewData] = useState<{
    isOpen: boolean;
    winner: PieceColor | null;
    reason: string;
    movesCount: number;
    playerMover: PieceColor;
    moveLog: MoveLogEntry[];
    eloChange: number;
  }>({
    isOpen: false,
    winner: null,
    reason: '',
    movesCount: 0,
    playerMover: 'w',
    moveLog: [],
    eloChange: 0
  });

  const handleUpdateProfile = (updated: Partial<PlayerProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...updated };
      savePlayerProfile(next);
      return next;
    });
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sounds.enabled = next;
    if (next) sounds.playMove();
  };

  const handleChallengeBot = (botId: string) => {
    setTargetChallengeBotId(botId);
    setActiveTab('ranked');
  };

  const handlePlayCustomPosition = (customState: GameState) => {
    setCustomGameState(customState);
    setActiveTab('ranked');
  };

  return (
    <div className="min-h-screen bg-[#0b0f14] text-[#e5edf5] font-sans antialiased pb-12 selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Header / App Shell Bar */}
      <header className="sticky top-0 z-40 bg-[#0f151d]/90 backdrop-blur-md border-b border-[#1c2938]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white text-xl shadow-md shadow-emerald-950/50">
              ♞
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-wide text-white leading-tight">
                CHECKMATE
              </h1>
              <p className="text-[10px] text-emerald-400 font-semibold tracking-wider uppercase">
                Chess Studio
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-[#141d27] p-1 rounded-xl border border-[#213042]">
            <button
              type="button"
              onClick={() => setActiveTab('ranked')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'ranked'
                  ? 'bg-emerald-600 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Swords className="w-3.5 h-3.5" />
              Ranked Match
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('daily')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'daily'
                  ? 'bg-emerald-600 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Puzzle className="w-3.5 h-3.5" />
              Daily Puzzles
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('rush')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'rush'
                  ? 'bg-emerald-600 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              Puzzle Rush
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'leaderboard'
                  ? 'bg-emerald-600 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              Leaderboard
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('cosmetics')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'cosmetics'
                  ? 'bg-emerald-600 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Armory
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'editor'
                  ? 'bg-emerald-600 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              Editor
            </button>
          </nav>

          {/* Quick Metrics & Sound */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Daily Streak */}
            <div
              title={`${profile.puzzleStreak} Day Tactical Streak`}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-orange-950/30 border border-orange-500/30 text-orange-400 font-bold text-xs"
            >
              <Flame className="w-3.5 h-3.5 fill-current" />
              <span>{profile.puzzleStreak}</span>
            </div>

            {/* Coins */}
            <div
              title={`${profile.coins} Chess Coins`}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-950/30 border border-amber-500/30 text-amber-300 font-bold text-xs font-mono"
            >
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>{profile.coins}</span>
            </div>

            {/* Rating */}
            <div
              title={`Elo Rating: ${profile.rating}`}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 font-bold text-xs font-mono"
            >
              <span>{profile.rating}</span>
              <span className="text-[10px] text-emerald-400/70 font-sans">Elo</span>
            </div>

            {/* Sound Toggle */}
            <button
              type="button"
              onClick={toggleSound}
              title={soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
              className="w-8 h-8 rounded-lg bg-[#141d27] hover:bg-[#1f2b38] border border-[#233346] text-slate-300 flex items-center justify-center cursor-pointer transition-colors"
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Horizontal Navigation Scroll */}
        <div className="md:hidden flex items-center gap-1 px-4 py-2 border-t border-[#182330] overflow-x-auto no-scrollbar">
          {(
            [
              { id: 'ranked', label: 'Ranked', icon: Swords },
              { id: 'daily', label: 'Daily', icon: Puzzle },
              { id: 'rush', label: 'Rush', icon: Zap },
              { id: 'leaderboard', label: 'Ladder', icon: Trophy },
              { id: 'cosmetics', label: 'Armory', icon: Sparkles },
              { id: 'editor', label: 'Editor', icon: Edit3 }
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1 rounded-lg text-xs font-bold shrink-0 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === item.id
                    ? 'bg-emerald-600 text-slate-950 font-extrabold'
                    : 'text-slate-400 hover:text-white bg-[#141d27]'
                }`}
              >
                <Icon className="w-3 h-3" />
                {item.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {activeTab === 'ranked' && (
          <RankedMatchView
            profile={profile}
            initialBotId={targetChallengeBotId}
            onUpdateProfile={handleUpdateProfile}
            onOpenReviewModal={(data) => {
              setReviewData({
                isOpen: true,
                winner: data.winner,
                reason: data.reason,
                movesCount: data.movesCount,
                playerMover: data.playerMover,
                moveLog: data.moveLog,
                eloChange: data.eloChange
              });
            }}
          />
        )}

        {activeTab === 'daily' && (
          <DailyPuzzleView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {activeTab === 'rush' && (
          <PuzzleRushView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {activeTab === 'leaderboard' && (
          <LeaderboardView
            profile={profile}
            onChallengeBot={handleChallengeBot}
          />
        )}

        {activeTab === 'cosmetics' && (
          <CosmeticsShop
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {activeTab === 'editor' && (
          <BoardEditorView
            profile={profile}
            onPlayCustomPosition={handlePlayCustomPosition}
          />
        )}
      </main>

      {/* Post Match Review Modal */}
      <GameReviewModal
        isOpen={reviewData.isOpen}
        winner={reviewData.winner}
        reason={reviewData.reason}
        movesCount={reviewData.movesCount}
        playerMover={reviewData.playerMover}
        moveLog={reviewData.moveLog}
        eloChange={reviewData.eloChange}
        onClose={() => setReviewData((prev) => ({ ...prev, isOpen: false }))}
        onRematch={() => {
          setReviewData((prev) => ({ ...prev, isOpen: false }));
          setActiveTab('ranked');
        }}
      />
    </div>
  );
}
