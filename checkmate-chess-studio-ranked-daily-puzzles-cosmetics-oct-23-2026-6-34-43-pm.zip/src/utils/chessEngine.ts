import {
  ChessMove,
  GameState,
  PieceCode,
  PieceColor,
  PieceType,
  GameTermination,
  MoveQuality
} from '../types/chess';

export const FILES = 'abcdefgh';

export function idx(file: number, rank: number): number {
  return (7 - rank) * 8 + file;
}

export function fileOf(i: number): number {
  return i % 8;
}

export function rankOf(i: number): number {
  return 7 - Math.floor(i / 8);
}

export function coord(i: number): string {
  return FILES[fileOf(i)] + (rankOf(i) + 1);
}

export function parseCoord(s: string): number {
  if (!s || s.length < 2) return 0;
  const f = FILES.indexOf(s[0].toLowerCase());
  const r = parseInt(s[1], 10) - 1;
  return idx(f, r);
}

export function colorOf(p: PieceCode | null): PieceColor | null {
  return p ? (p[0] as PieceColor) : null;
}

export function typeOf(p: PieceCode | null): PieceType | null {
  return p ? (p[1] as PieceType) : null;
}

export function opposite(c: PieceColor): PieceColor {
  return c === 'w' ? 'b' : 'w';
}

export function inside(f: number, r: number): boolean {
  return f >= 0 && f < 8 && r >= 0 && r < 8;
}

export const PIECE_VALUES: Record<PieceType, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000
};

// Piece Square Tables for positional evaluation
const PAWN_PST = [
   0,  0,  0,  0,  0,  0,  0,  0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
   5,  5, 10, 25, 25, 10,  5,  5,
   0,  0,  0, 20, 20,  0,  0,  0,
   5, -5,-10,  0,  0,-10, -5,  5,
   5, 10, 10,-20,-20, 10, 10,  5,
   0,  0,  0,  0,  0,  0,  0,  0
];

const KNIGHT_PST = [
  -50,-40,-30,-30,-30,-30,-40,-50,
  -40,-20,  0,  0,  0,  0,-20,-40,
  -30,  0, 10, 15, 15, 10,  0,-30,
  -30,  5, 15, 20, 20, 15,  5,-30,
  -30,  0, 15, 20, 20, 15,  0,-30,
  -30,  5, 10, 15, 15, 10,  5,-30,
  -40,-20,  0,  5,  5,  0,-20,-40,
  -50,-40,-30,-30,-30,-30,-40,-50
];

const BISHOP_PST = [
  -20,-10,-10,-10,-10,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5, 10, 10,  5,  0,-10,
  -10,  5,  5, 10, 10,  5,  5,-10,
  -10,  0, 10, 10, 10, 10,  0,-10,
  -10, 10, 10, 10, 10, 10, 10,-10,
  -10,  5,  0,  0,  0,  0,  5,-10,
  -20,-10,-10,-10,-10,-10,-10,-20
];

export function cloneState(s: GameState): GameState {
  return {
    board: s.board.slice(),
    turn: s.turn,
    castle: { ...s.castle },
    ep: s.ep,
    halfmove: s.halfmove,
    fullmove: s.fullmove
  };
}

export function parseFEN(fen: string): GameState {
  const parts = fen.trim().split(/\s+/);
  const rows = parts[0].split('/');
  const board: (PieceCode | null)[] = Array(64).fill(null);

  for (let r = 0; r < 8; r++) {
    const row = rows[r] || '';
    let file = 0;
    for (let c = 0; c < row.length; c++) {
      const char = row[c];
      if (char >= '1' && char <= '8') {
        file += parseInt(char, 10);
      } else {
        const color: PieceColor = char === char.toUpperCase() ? 'w' : 'b';
        const type = char.toLowerCase() as PieceType;
        board[r * 8 + file] = `${color}${type}` as PieceCode;
        file++;
      }
    }
  }

  const turn: PieceColor = parts[1] === 'b' ? 'b' : 'w';
  const castlePart = parts[2] || '-';
  const castle = {
    K: castlePart.includes('K'),
    Q: castlePart.includes('Q'),
    k: castlePart.includes('k'),
    q: castlePart.includes('q')
  };

  const epPart = parts[3] || '-';
  const ep = epPart !== '-' && epPart.length >= 2 ? parseCoord(epPart) : null;
  const halfmove = parts[4] ? parseInt(parts[4], 10) || 0 : 0;
  const fullmove = parts[5] ? parseInt(parts[5], 10) || 1 : 1;

  return { board, turn, castle, ep, halfmove, fullmove };
}

export function stateToFEN(s: GameState): string {
  const rows: string[] = [];
  for (let r = 0; r < 8; r++) {
    let empty = 0;
    let rowStr = '';
    for (let f = 0; f < 8; f++) {
      const p = s.board[r * 8 + f];
      if (!p) {
        empty++;
      } else {
        if (empty > 0) {
          rowStr += empty;
          empty = 0;
        }
        const letter = p[0] === 'w' ? p[1].toUpperCase() : p[1].toLowerCase();
        rowStr += letter;
      }
    }
    if (empty > 0) rowStr += empty;
    rows.push(rowStr);
  }

  const cStr =
    (s.castle.K ? 'K' : '') +
    (s.castle.Q ? 'Q' : '') +
    (s.castle.k ? 'k' : '') +
    (s.castle.q ? 'q' : '') || '-';

  const epStr = s.ep !== null ? coord(s.ep) : '-';
  return `${rows.join('/')} ${s.turn} ${cStr} ${epStr} ${s.halfmove} ${s.fullmove}`;
}

export function initialStandardState(): GameState {
  return parseFEN('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
}

export function kingSquare(s: GameState, c: PieceColor): number {
  return s.board.findIndex((p) => p === `${c}k`);
}

export function attacked(s: GameState, sq: number, by: PieceColor): boolean {
  if (sq < 0 || sq >= 64) return false;
  const f = fileOf(sq);
  const r = rankOf(sq);
  const b = s.board;

  // Pawns
  const pawnDir = by === 'w' ? -1 : 1;
  const pawnRank = r + pawnDir;
  for (const df of [-1, 1]) {
    const pawnFile = f + df;
    if (inside(pawnFile, pawnRank) && b[idx(pawnFile, pawnRank)] === `${by}p`) {
      return true;
    }
  }

  // Knights
  const knightDeltas = [
    [1, 2], [2, 1], [-1, 2], [-2, 1],
    [1, -2], [2, -1], [-1, -2], [-2, -1]
  ];
  for (const [df, dr] of knightDeltas) {
    const x = f + df;
    const y = r + dr;
    if (inside(x, y) && b[idx(x, y)] === `${by}n`) return true;
  }

  // Kings
  for (let df = -1; df <= 1; df++) {
    for (let dr = -1; dr <= 1; dr++) {
      if (df === 0 && dr === 0) continue;
      const x = f + df;
      const y = r + dr;
      if (inside(x, y) && b[idx(x, y)] === `${by}k`) return true;
    }
  }

  // Sliders
  const dirs: [number, number, string][] = [
    [1, 0, 'rq'], [-1, 0, 'rq'], [0, 1, 'rq'], [0, -1, 'rq'],
    [1, 1, 'bq'], [1, -1, 'bq'], [-1, 1, 'bq'], [-1, -1, 'bq']
  ];

  for (const [df, dr, types] of dirs) {
    let x = f + df;
    let y = r + dr;
    while (inside(x, y)) {
      const p = b[idx(x, y)];
      if (p) {
        if (colorOf(p) === by && types.includes(typeOf(p)!)) return true;
        break;
      }
      x += df;
      y += dr;
    }
  }

  return false;
}

export function inCheck(s: GameState, c: PieceColor): boolean {
  const ks = kingSquare(s, c);
  if (ks === -1) return false;
  return attacked(s, ks, opposite(c));
}

export function pseudoMoves(s: GameState, from: number): ChessMove[] {
  const b = s.board;
  const p = b[from];
  if (!p) return [];
  const c = colorOf(p)!;
  const t = typeOf(p)!;
  const f = fileOf(from);
  const r = rankOf(from);
  const out: ChessMove[] = [];

  const add = (to: number, extra: Partial<ChessMove> = {}) => {
    if (to < 0 || to >= 64) return;
    const target = b[to];
    if (target && colorOf(target) === c) return;
    if (target && typeOf(target) === 'k') return;
    out.push({ from, to, capture: !!target, ...extra });
  };

  if (t === 'p') {
    const dir = c === 'w' ? 1 : -1;
    const startRank = c === 'w' ? 1 : 6;
    const promRank = c === 'w' ? 7 : 0;
    const nextRank = r + dir;

    // Single step
    if (inside(f, nextRank) && !b[idx(f, nextRank)]) {
      const to = idx(f, nextRank);
      add(to, nextRank === promRank ? { promotion: true } : {});

      // Double step
      const doubleRank = r + 2 * dir;
      if (r === startRank && inside(f, doubleRank) && !b[idx(f, doubleRank)]) {
        add(idx(f, doubleRank), { double: true });
      }
    }

    // Captures & En Passant
    for (const df of [-1, 1]) {
      const nf = f + df;
      if (!inside(nf, nextRank)) continue;
      const to = idx(nf, nextRank);
      if (b[to] && colorOf(b[to]) !== c && typeOf(b[to]) !== 'k') {
        add(to, nextRank === promRank ? { promotion: true } : {});
      } else if (s.ep === to) {
        out.push({ from, to, enPassant: true, capture: true });
      }
    }
  } else if (t === 'n') {
    const deltas = [
      [1, 2], [2, 1], [-1, 2], [-2, 1],
      [1, -2], [2, -1], [-1, -2], [-2, -1]
    ];
    for (const [df, dr] of deltas) {
      if (inside(f + df, r + dr)) add(idx(f + df, r + dr));
    }
  } else if (t === 'k') {
    for (let df = -1; df <= 1; df++) {
      for (let dr = -1; dr <= 1; dr++) {
        if (df || dr) {
          if (inside(f + df, r + dr)) add(idx(f + df, r + dr));
        }
      }
    }

    // Castling
    if (c === 'w' && from === 60 && !inCheck(s, 'w')) {
      if (s.castle.K && !b[61] && !b[62] && b[63] === 'wr' && !attacked(s, 61, 'b') && !attacked(s, 62, 'b')) {
        out.push({ from, to: 62, castle: 'K' });
      }
      if (s.castle.Q && !b[59] && !b[58] && !b[57] && b[56] === 'wr' && !attacked(s, 59, 'b') && !attacked(s, 58, 'b')) {
        out.push({ from, to: 58, castle: 'Q' });
      }
    }
    if (c === 'b' && from === 4 && !inCheck(s, 'b')) {
      if (s.castle.k && !b[5] && !b[6] && b[7] === 'br' && !attacked(s, 5, 'w') && !attacked(s, 6, 'w')) {
        out.push({ from, to: 6, castle: 'k' });
      }
      if (s.castle.q && !b[3] && !b[2] && !b[1] && b[0] === 'br' && !attacked(s, 3, 'w') && !attacked(s, 2, 'w')) {
        out.push({ from, to: 2, castle: 'q' });
      }
    }
  } else {
    const dirs =
      t === 'b'
        ? [[1, 1], [1, -1], [-1, 1], [-1, -1]]
        : t === 'r'
        ? [[1, 0], [-1, 0], [0, 1], [0, -1]]
        : [[1, 1], [1, -1], [-1, 1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]];

    for (const [df, dr] of dirs) {
      let x = f + df;
      let y = r + dr;
      while (inside(x, y)) {
        const to = idx(x, y);
        if (!b[to]) {
          out.push({ from, to });
        } else {
          if (colorOf(b[to]) !== c && typeOf(b[to]) !== 'k') {
            add(to);
          }
          break;
        }
        x += df;
        y += dr;
      }
    }
  }

  return out;
}

export function applyMove(s: GameState, m: ChessMove, promo: PieceType = 'q'): GameState {
  const n = cloneState(s);
  const b = n.board;
  const p = b[m.from];
  if (!p) return n;

  const c = colorOf(p)!;
  const t = typeOf(p)!;
  let target = b[m.to];
  n.ep = null;

  if (m.enPassant) {
    const epSquare = m.to + (c === 'w' ? 8 : -8);
    target = b[epSquare];
    b[epSquare] = null;
  }

  b[m.to] = p;
  b[m.from] = null;

  if (m.promotion) {
    b[m.to] = `${c}${m.promote || promo}` as PieceCode;
  }

  if (m.castle) {
    if (m.castle === 'K') {
      b[61] = b[63];
      b[63] = null;
    } else if (m.castle === 'Q') {
      b[59] = b[56];
      b[56] = null;
    } else if (m.castle === 'k') {
      b[5] = b[7];
      b[7] = null;
    } else if (m.castle === 'q') {
      b[3] = b[0];
      b[0] = null;
    }
  }

  // Update castling rights
  if (p === 'wk') {
    n.castle.K = false;
    n.castle.Q = false;
  }
  if (p === 'bk') {
    n.castle.k = false;
    n.castle.q = false;
  }
  if (m.from === 63 || m.to === 63) n.castle.K = false;
  if (m.from === 56 || m.to === 56) n.castle.Q = false;
  if (m.from === 7 || m.to === 7) n.castle.k = false;
  if (m.from === 0 || m.to === 0) n.castle.q = false;

  // En passant square
  if (t === 'p' && Math.abs(m.to - m.from) === 16) {
    n.ep = (m.from + m.to) / 2;
  }

  n.halfmove = t === 'p' || target ? 0 : s.halfmove + 1;
  if (c === 'b') n.fullmove = s.fullmove + 1;
  n.turn = opposite(c);

  return n;
}

export function legalMoves(s: GameState, from: number | null = null): ChessMove[] {
  const moves: ChessMove[] = [];
  for (let i = 0; i < 64; i++) {
    if (from !== null && i !== from) continue;
    const p = s.board[i];
    if (!p || colorOf(p) !== s.turn) continue;

    for (const m of pseudoMoves(s, i)) {
      const next = applyMove(s, m);
      if (!inCheck(next, colorOf(p)!)) {
        moves.push(m);
      }
    }
  }
  return moves;
}

export function sanFor(s: GameState, m: ChessMove, allLegalMoves?: ChessMove[]): string {
  const p = s.board[m.from];
  if (!p) return '';
  const t = typeOf(p)!;
  const dest = coord(m.to);
  const capture = m.capture || m.enPassant;
  let pre = '';

  if (m.castle) {
    pre = m.castle === 'K' || m.castle === 'k' ? 'O-O' : 'O-O-O';
  } else {
    if (t !== 'p') {
      pre = t.toUpperCase();
      const all = allLegalMoves || legalMoves(s);
      const peers = all.filter(
        (x) => x.from !== m.from && x.to === m.to && typeOf(s.board[x.from]) === t
      );
      if (peers.length > 0) {
        const sameFile = peers.some((x) => fileOf(x.from) === fileOf(m.from));
        const sameRank = peers.some((x) => rankOf(x.from) === rankOf(m.from));
        if (!sameFile) pre += FILES[fileOf(m.from)];
        else if (!sameRank) pre += rankOf(m.from) + 1;
        else pre += coord(m.from);
      }
    } else if (capture) {
      pre = FILES[fileOf(m.from)];
    }

    pre += (capture ? 'x' : '') + dest;
    if (m.promotion) {
      pre += '=' + (m.promote || 'q').toUpperCase();
    }
  }

  const next = applyMove(s, m, m.promote || 'q');
  const opp = next.turn;
  const oppLegals = legalMoves(next);
  if (inCheck(next, opp)) {
    pre += oppLegals.length === 0 ? '#' : '+';
  }

  return pre;
}

export function positionKey(s: GameState): string {
  const pieces = s.board.map((p) => p || '.').join('');
  const c = Object.keys(s.castle).filter((k) => s.castle[k as keyof typeof s.castle]).join('');
  const ep = s.ep === null ? '-' : coord(s.ep);
  return `${pieces} ${s.turn} ${c} ${ep}`;
}

export function isInsufficientMaterial(s: GameState): boolean {
  const pieces = s.board.filter(Boolean) as PieceCode[];
  const nonKings = pieces.filter((p) => typeOf(p) !== 'k');
  if (nonKings.length === 0) return true;
  if (nonKings.length === 1 && (typeOf(nonKings[0]) === 'b' || typeOf(nonKings[0]) === 'n')) return true;
  if (nonKings.every((p) => typeOf(p) === 'b')) {
    const bishops: number[] = [];
    for (let i = 0; i < 64; i++) {
      if (s.board[i] && typeOf(s.board[i]) === 'b') {
        bishops.push((fileOf(i) + rankOf(i)) % 2);
      }
    }
    if (bishops.length > 0 && bishops.every((x) => x === bishops[0])) return true;
  }
  return false;
}

export function terminalState(s: GameState, repetitionCount = 1): GameTermination {
  const moves = legalMoves(s);
  if (moves.length === 0) {
    if (inCheck(s, s.turn)) {
      const winner = opposite(s.turn);
      return {
        over: true,
        winner,
        reason: 'Checkmate',
        result: winner === 'w' ? 'White wins by checkmate' : 'Black wins by checkmate'
      };
    }
    return { over: true, winner: null, reason: 'Stalemate', result: 'Draw by stalemate' };
  }

  if (s.halfmove >= 100) {
    return { over: true, winner: null, reason: '50-Move Rule', result: 'Draw by 50-move rule' };
  }

  if (isInsufficientMaterial(s)) {
    return { over: true, winner: null, reason: 'Insufficient Material', result: 'Draw by insufficient material' };
  }

  if (repetitionCount >= 3) {
    return { over: true, winner: null, reason: 'Threefold Repetition', result: 'Draw by threefold repetition' };
  }

  return { over: false };
}

export function evaluateBoard(s: GameState): number {
  let score = 0;
  for (let i = 0; i < 64; i++) {
    const p = s.board[i];
    if (!p) continue;
    const c = colorOf(p)!;
    const t = typeOf(p)!;
    const f = fileOf(i);
    const r = rankOf(i);
    const relativeRank = c === 'w' ? r : 7 - r;
    const center = 3.5 - (Math.abs(f - 3.5) + Math.abs(r - 3.5)) / 2;

    let val = PIECE_VALUES[t];
    if (t === 'p') {
      const pIdx = c === 'w' ? (7 - r) * 8 + f : r * 8 + f;
      val += PAWN_PST[pIdx] * 0.5 + relativeRank * 5;
    } else if (t === 'n') {
      const nIdx = c === 'w' ? (7 - r) * 8 + f : r * 8 + f;
      val += KNIGHT_PST[nIdx] * 0.4 + center * 10;
    } else if (t === 'b') {
      const bIdx = c === 'w' ? (7 - r) * 8 + f : r * 8 + f;
      val += BISHOP_PST[bIdx] * 0.3 + center * 8;
    } else if (t === 'r') {
      if (relativeRank === 6) val += 20; // 7th rank rook
    } else if (t === 'q') {
      val += center * 4;
    } else if (t === 'k' && s.fullmove < 25) {
      val -= center * 10; // keep king tucked early
    }

    score += (c === 'w' ? 1 : -1) * val;
  }
  return score;
}

function moveScore(s: GameState, m: ChessMove): number {
  const p = s.board[m.from];
  const victim = m.enPassant ? 'p' : typeOf(s.board[m.to]);
  let score = 0;
  if (victim) {
    score += 10 * PIECE_VALUES[victim] - (p ? PIECE_VALUES[typeOf(p)!] : 0);
  }
  if (m.promotion) score += PIECE_VALUES.q;
  if (m.castle) score += 40;
  return score;
}

export function minimax(
  s: GameState,
  depth: number,
  alpha: number,
  beta: number,
  ply = 0
): number {
  const moves = legalMoves(s);
  if (moves.length === 0) {
    if (inCheck(s, s.turn)) {
      return s.turn === 'w' ? -30000 + ply : 30000 - ply;
    }
    return 0; // Stalemate
  }

  if (s.halfmove >= 100 || isInsufficientMaterial(s)) return 0;
  if (depth <= 0) return evaluateBoard(s);

  moves.sort((a, b) => moveScore(s, b) - moveScore(s, a));

  const maximizing = s.turn === 'w';
  let bestVal = maximizing ? -Infinity : Infinity;

  for (const m of moves) {
    const next = applyMove(s, m, m.promote || 'q');
    const v = minimax(next, depth - 1, alpha, beta, ply + 1);
    if (maximizing) {
      bestVal = Math.max(bestVal, v);
      alpha = Math.max(alpha, bestVal);
    } else {
      bestVal = Math.min(bestVal, v);
      beta = Math.min(beta, bestVal);
    }
    if (beta <= alpha) break;
  }

  return bestVal;
}

export function chooseEngineMove(
  s: GameState,
  depth = 3,
  blunderRate = 0
): { move: ChessMove; score: number } | null {
  const moves = legalMoves(s);
  if (moves.length === 0) return null;

  // Intentional blunder for lower difficulty bots
  if (blunderRate > 0 && Math.random() < blunderRate && moves.length > 1) {
    // Pick a random legal move
    const randomMove = moves[Math.floor(Math.random() * moves.length)];
    return { move: randomMove, score: 0 };
  }

  moves.sort((a, b) => moveScore(s, b) - moveScore(s, a));

  const maximizing = s.turn === 'w';
  let bestScore = maximizing ? -Infinity : Infinity;
  let candidates: { move: ChessMove; score: number }[] = [];

  for (const m of moves) {
    const next = applyMove(s, m, m.promote || 'q');
    const v = minimax(next, depth - 1, -Infinity, Infinity, 1);

    if (maximizing ? v > bestScore : v < bestScore) {
      bestScore = v;
      candidates = [{ move: m, score: v }];
    } else if (Math.abs(v - bestScore) < 18) {
      candidates.push({ move: m, score: v });
    }
  }

  const chosen = candidates[Math.floor(Math.random() * candidates.length)] || {
    move: moves[0],
    score: 0
  };
  return chosen;
}

export function classifyCpLoss(cpLoss: number): MoveQuality['cls'] {
  if (cpLoss <= 5) return 'brilliant';
  if (cpLoss <= 35) return 'good';
  if (cpLoss <= 80) return 'inaccuracy';
  if (cpLoss <= 200) return 'mistake';
  return 'blunder';
}

export function evaluatePlayedMove(
  before: GameState,
  played: ChessMove,
  mover: PieceColor
): MoveQuality {
  const moves = legalMoves(before);
  if (moves.length === 0) return { cpLoss: 0, cls: 'good' };

  const sign = mover === 'w' ? 1 : -1;
  let bestVal = -Infinity;

  for (const m of moves) {
    const next = applyMove(before, m, m.promote || 'q');
    const val = sign * evaluateBoard(next);
    if (val > bestVal) bestVal = val;
  }

  const after = applyMove(before, played, played.promote || 'q');
  const playedVal = sign * evaluateBoard(after);
  const cpLoss = Math.max(0, bestVal - playedVal);

  return { cpLoss, cls: classifyCpLoss(cpLoss) };
}
