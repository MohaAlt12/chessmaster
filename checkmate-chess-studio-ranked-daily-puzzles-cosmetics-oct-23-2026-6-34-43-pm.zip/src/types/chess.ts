export type PieceColor = 'w' | 'b';
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';

export type PieceCode = `${PieceColor}${PieceType}`;

export interface ChessMove {
  from: number; // 0..63
  to: number;   // 0..63
  capture?: boolean;
  promotion?: boolean;
  promote?: PieceType;
  castle?: 'K' | 'Q' | 'k' | 'q';
  enPassant?: boolean;
  double?: boolean;
  san?: string;
  evalCls?: 'brilliant' | 'good' | 'inaccuracy' | 'mistake' | 'blunder';
}

export interface CastlingRights {
  K: boolean; // White kingside
  Q: boolean; // White queenside
  k: boolean; // Black kingside
  q: boolean; // Black queenside
}

export interface GameState {
  board: (PieceCode | null)[];
  turn: PieceColor;
  castle: CastlingRights;
  ep: number | null; // en passant target square
  halfmove: number;
  fullmove: number;
}

export interface GameTermination {
  over: boolean;
  winner?: PieceColor | null;
  reason?: string;
  result?: string;
}

export interface MoveQuality {
  cpLoss: number;
  cls: 'brilliant' | 'good' | 'inaccuracy' | 'mistake' | 'blunder';
}

export interface MoveLogEntry {
  mover: PieceColor;
  notation: string;
  from: number;
  to: number;
  cls?: 'brilliant' | 'good' | 'inaccuracy' | 'mistake' | 'blunder';
  boardSnapshot: (PieceCode | null)[];
}

// Puzzle System
export interface Puzzle {
  id: string;
  title: string;
  theme: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Master';
  rating: number;
  fen: string;
  playerColor: PieceColor;
  solutionUci: string[]; // e.g. ["e2e4", "e7e5", ...]
  explanation: string;
  dateKey?: string; // YYYY-MM-DD for daily puzzles
}

// Leaderboard & Rating
export type RankTier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond' | 'Master' | 'Grandmaster';

export interface BotPersonality {
  id: string;
  name: string;
  title?: string;
  avatar: string;
  tier: RankTier;
  rating: number;
  aiDepth: number;
  blunderRate: number; // 0 to 0.4
  playstyle: string;
  quote: string;
  unlockedByDefault?: boolean;
}

export interface LeaderboardPlayer {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  tier: RankTier;
  isUser?: boolean;
  wins: number;
  losses: number;
  draws: number;
  streak: number;
  botId?: string;
}

// Cosmetics
export interface PieceSetOption {
  id: string;
  name: string;
  description: string;
  price: number; // 0 for free
  previewGlyphs: { w: string; b: string };
  glyphs: {
    w: Record<PieceType, string>;
    b: Record<PieceType, string>;
  };
  styleClass?: string;
}

export interface BoardThemeOption {
  id: string;
  name: string;
  description: string;
  price: number;
  light: string;
  dark: string;
  sel: string;
  legal: string;
  accent: string;
  previewClass?: string;
}

// Player Profile & Progress
export interface PlayerProfile {
  name: string;
  rating: number;
  coins: number;
  puzzleStreak: number;
  lastDailySolvedDate: string | null;
  puzzlesSolvedCount: number;
  rankedWins: number;
  rankedLosses: number;
  rankedDraws: number;
  equippedPieceSet: string;
  equippedBoardTheme: string;
  unlockedPieceSets: string[];
  unlockedBoardThemes: string[];
  puzzleRushHighScore: number;
}
